package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.LocalMediaResolver
import com.example.data.WellnessRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context matches Wellness Learning Hub`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Wellness Learning Hub", appName)
    }

    @Test
    fun `all 4 HTE devices resolve their individual local equipment photographs`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        LocalMediaResolver.clearCacheForTesting()

        val repo = WellnessRepository()
        val devices = repo.getDevices()
        assertEquals(4, devices.size)

        val resolvedUris = devices.map { device ->
            val resolved = LocalMediaResolver.resolveMedia(
                context = context,
                localAssetBasePath = device.localAssetBasePath,
                remoteUrl = device.officialImageUrl,
                remoteSourceLabel = null,
                localSourceLabel = "Fotografía del equipo · Ref. SOQI Universe"
            )
            assertTrue("Expected local asset for ${device.name}", resolved.isLocalAsset)
            assertNotNull("Expected resolved URI for ${device.name}", resolved.model)
            assertTrue(resolved.model!!.startsWith("file:///android_asset/images/equipos/"))
            resolved.model!!
        }

        assertEquals(4, resolvedUris.toSet().size)
    }

    @Test
    fun `home editorial assets and foam roller video illustration resolve locally`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        LocalMediaResolver.clearCacheForTesting()

        val expectedLocalPaths = listOf(
            "images/inicio/inicio_videos",
            "images/inicio/inicio_tecnologias",
            "images/inicio/inicio_comunidad",
            "images/inicio/inicio_fuentes",
            "images/videos/video_gaiam_foam_roller"
        )

        val resolved = expectedLocalPaths.mapNotNull { path ->
            LocalMediaResolver.resolveLocalAssetUri(context, path)
        }
        assertEquals(expectedLocalPaths.size, resolved.size)
        assertEquals(expectedLocalPaths.size, resolved.toSet().size)
    }

    @Test
    fun `every video card has a unique visual source and preserves real YouTube links`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        LocalMediaResolver.clearCacheForTesting()

        val repo = WellnessRepository()
        val videos = repo.getVideos()
        assertEquals(9, videos.size)

        val resolvedModels = videos.map { video ->
            assertTrue(video.videoUrl.startsWith("https://www.youtube.com/@"))
            assertTrue(video.channelUrl.startsWith("https://www.youtube.com/@"))
            assertNull(video.youtubeVideoId)

            val resolved = LocalMediaResolver.resolveMedia(
                context = context,
                localAssetBasePath = video.localAssetBasePath,
                remoteUrl = video.thumbnailUrl ?: video.illustrativeImageUrl,
                remoteSourceLabel = video.illustrativeAttribution
            )
            assertNotNull("Missing visual for video ${video.id}", resolved.model)
            resolved.model!!
        }

        assertEquals(videos.size, resolvedModels.toSet().size)
    }

    @Test
    fun `all superfoods nutrition and movement items have unique local paths and non-duplicated images`() {
        val repo = WellnessRepository()
        val superfoods = repo.getSuperfoods()
        val nutrition = repo.getNutritionTopics()
        val movement = repo.getMovementRoutines()
        val videos = repo.getVideos()

        assertEquals(10, superfoods.size)
        assertEquals(9, nutrition.size)
        assertEquals(6, movement.size)

        val requiredIngredients = listOf(
            "Reishi",
            "Melena de León",
            "Cordyceps",
            "Jengibre",
            "Ginseng",
            "Ashwagandha"
        )
        requiredIngredients.forEach { name ->
            assertTrue("Missing ingredient $name", superfoods.any { it.name.contains(name, ignoreCase = true) })
        }
        assertTrue(nutrition.any { it.tag.equals("Carbohidratos", ignoreCase = true) })

        val allLocalPaths = superfoods.map { it.localAssetBasePath } +
            nutrition.map { it.localAssetBasePath } +
            movement.map { it.localAssetBasePath } +
            videos.map { it.localAssetBasePath }
        assertEquals(allLocalPaths.size, allLocalPaths.toSet().size)

        val allRemoteUrls = superfoods.map { it.imageUrl } +
            nutrition.map { it.imageUrl } +
            movement.map { it.imageUrl } +
            videos.mapNotNull { it.illustrativeImageUrl }
        assertTrue(allRemoteUrls.all { it.startsWith("https://commons.wikimedia.org/") })
        assertEquals(allRemoteUrls.size, allRemoteUrls.toSet().size)
    }

    @Test
    fun `media resolver returns placeholder only when both local asset and fallback URL are absent`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        LocalMediaResolver.clearCacheForTesting()

        val absentMedia = LocalMediaResolver.resolveMedia(
            context = context,
            localAssetBasePath = "images/equipos/equipo_inexistente",
            remoteUrl = null,
            remoteSourceLabel = null,
            pendingLabel = "Espacio reservado · Archivo local pendiente"
        )

        assertNull(absentMedia.model)
        assertFalse(absentMedia.isLocalAsset)
        assertTrue(absentMedia.provenanceLabel.contains("pendiente", ignoreCase = true))
    }
}
