package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.remember
import com.example.R
import com.example.data.EducationalVideo
import com.example.data.LocalMediaResolver
import com.example.data.VideoCategory
import com.example.data.VideoChannel
import com.example.ui.components.AdaptiveContentBox
import com.example.ui.components.BookmarkToggleButton
import com.example.ui.components.ExternalLinkOutlinedButton
import com.example.ui.components.NeutralMediaPlaceholder
import com.example.ui.components.RemoteWellnessImage
import com.example.ui.components.openExternalUrl

@Composable
fun VideosScreen(
    videos: List<EducationalVideo>,
    selectedChannel: VideoChannel?,
    selectedCategory: VideoCategory,
    searchQuery: String,
    savedIds: Set<String>,
    onSelectChannel: (VideoChannel?) -> Unit,
    onSelectCategory: (VideoCategory) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onToggleBookmark: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    AdaptiveContentBox(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Descubre rutinas confiables",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        text = "Selección curada de fisioterapia, estiramientos, yoga, movilidad y rodillo de masaje. Los enlaces abren los canales oficiales en YouTube; cuando no hay miniatura oficial verificada por ID, se muestra una imagen ilustrativa temática de apoyo sin sustituir los enlaces reales.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("videos_search_input"),
                    placeholder = { Text("Buscar por espalda, cuello, rodillas, yoga...") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Buscar videos"
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { onSearchQueryChange("") },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Limpiar búsqueda"
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = MaterialTheme.shapes.medium
                )
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Canales iniciales verificados",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ChannelHighlightCard(
                            channel = VideoChannel.TONE_AND_TIGHTEN,
                            isSelected = selectedChannel == VideoChannel.TONE_AND_TIGHTEN,
                            onSelect = {
                                onSelectChannel(
                                    if (selectedChannel == VideoChannel.TONE_AND_TIGHTEN) null
                                    else VideoChannel.TONE_AND_TIGHTEN
                                )
                            },
                            onOpenChannel = { openExternalUrl(context, VideoChannel.TONE_AND_TIGHTEN.channelUrl) },
                            modifier = Modifier.weight(1f)
                        )
                        ChannelHighlightCard(
                            channel = VideoChannel.GAIAM,
                            isSelected = selectedChannel == VideoChannel.GAIAM,
                            onSelect = {
                                onSelectChannel(
                                    if (selectedChannel == VideoChannel.GAIAM) null
                                    else VideoChannel.GAIAM
                                )
                            },
                            onOpenChannel = { openExternalUrl(context, VideoChannel.GAIAM.channelUrl) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(VideoCategory.entries) { category ->
                        FilterChip(
                            selected = selectedCategory == category,
                            onClick = { onSelectCategory(category) },
                            label = { Text(category.label) },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("video_cat_${category.name}")
                        )
                    }
                }
            }

            if (videos.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.VideoLibrary,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(36.dp)
                            )
                            Text(
                                text = "Sin coincidencias en el catálogo",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Prueba limpiando el filtro de categoría o explorando directamente los canales oficiales arriba.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(videos, key = { it.id }) { video ->
                    VideoDiscoveryCard(
                        video = video,
                        isSaved = video.id in savedIds,
                        onToggleBookmark = { onToggleBookmark(video.id) },
                        onOpenVideo = { openExternalUrl(context, video.videoUrl) },
                        onOpenChannel = { openExternalUrl(context, video.channelUrl) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ChannelHighlightCard(
    channel: VideoChannel,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onOpenChannel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onSelect)
            .testTag("channel_filter_${channel.name}"),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
            }
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = channel.displayName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = onOpenChannel,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                        contentDescription = "Abrir canal ${channel.displayName}",
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Text(
                text = channel.handle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = channel.specialty,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun VideoDiscoveryCard(
    video: EducationalVideo,
    isSaved: Boolean,
    onToggleBookmark: () -> Unit,
    onOpenVideo: () -> Unit,
    onOpenChannel: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("video_card_${video.id}"),
        shape = MaterialTheme.shapes.large,
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        val context = LocalContext.current
        val isOfficialThumb = video.thumbnailUrl != null
        val displayUrl = video.thumbnailUrl ?: video.illustrativeImageUrl
        val remoteLabel = if (isOfficialThumb) {
            "Miniatura oficial YouTube"
        } else {
            video.illustrativeAttribution ?: "Imagen ilustrativa temática"
        }
        val resolvedMedia = remember(video.localAssetBasePath, displayUrl, remoteLabel) {
            LocalMediaResolver.resolveMedia(
                context = context,
                localAssetBasePath = video.localAssetBasePath,
                remoteUrl = displayUrl,
                remoteSourceLabel = remoteLabel,
                localSourceLabel = video.illustrativeAttribution ?: "Ilustración temática de apoyo",
                pendingLabel = "ID de YouTube pendiente de verificación"
            )
        }

        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clickable(onClick = onOpenVideo)
            ) {
                if (resolvedMedia.model != null) {
                    RemoteWellnessImage(
                        imageUrl = displayUrl,
                        contentDescription = if (isOfficialThumb) {
                            "Miniatura oficial de YouTube: ${video.title}"
                        } else {
                            "Imagen ilustrativa de apoyo para: ${video.title}"
                        },
                        fallbackTitle = video.title,
                        fallbackSubtitle = "${video.channel.displayName} · Abre el enlace en YouTube",
                        fallbackIcon = Icons.Outlined.PlayCircle,
                        fallbackDrawableRes = R.drawable.ic_fallback_video,
                        localAssetBasePath = video.localAssetBasePath,
                        remoteSourceLabel = remoteLabel,
                        localSourceLabel = video.illustrativeAttribution ?: "Ilustración temática de apoyo",
                        aspectRatio = 16f / 9f,
                        modifier = Modifier.fillMaxSize(),
                        targetWidthPx = 640,
                        targetHeightPx = 360
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.22f))
                    )
                } else {
                    NeutralMediaPlaceholder(
                        title = video.title,
                        subtitle = "${video.channel.displayName} · Identificador de YouTube pendiente; abre el canal o búsqueda oficial",
                        icon = Icons.Outlined.PlayCircle,
                        fallbackDrawableRes = R.drawable.ic_fallback_video,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.Black.copy(alpha = 0.78f),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(12.dp)
                ) {
                    Text(
                        text = video.estimatedDuration,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                ) {
                    Text(
                        text = video.category.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "${video.channel.displayName} · ${video.channel.handle}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = video.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    BookmarkToggleButton(
                        isSaved = isSaved,
                        onToggle = onToggleBookmark,
                        testTag = "bookmark_video_${video.id}"
                    )
                }

                Text(
                    text = video.focusSummary,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = "${video.viewsNote} · ${resolvedMedia.provenanceLabel}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.tertiary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onOpenVideo,
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("open_video_${video.id}"),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ver en YouTube")
                    }
                    ExternalLinkOutlinedButton(
                        label = "Canal",
                        onClick = onOpenChannel,
                        testTag = "open_channel_${video.id}"
                    )
                }
            }
        }
    }
}
