package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette - Warm Botanical Sage, Linen & Terracotta
val SagePrimary = Color(0xFF1F513F)
val OnSagePrimary = Color(0xFFFFFFFF)
val SagePrimaryContainer = Color(0xFFCDE9DA)
val OnSagePrimaryContainer = Color(0xFF062116)

val TerracottaSecondary = Color(0xFF9B5333)
val OnTerracottaSecondary = Color(0xFFFFFFFF)
val TerracottaContainer = Color(0xFFFFDBD0)
val OnTerracottaContainer = Color(0xFF3A1303)

val AmberTertiary = Color(0xFF7B5700)
val OnAmberTertiary = Color(0xFFFFFFFF)
val AmberTertiaryContainer = Color(0xFFFFDEA4)
val OnAmberTertiaryContainer = Color(0xFF271900)

val CreamBackground = Color(0xFFFBF9F4)
val OnCreamBackground = Color(0xFF181D1A)
val CreamSurface = Color(0xFFFBF9F4)
val OnCreamSurface = Color(0xFF181D1A)
val WarmSandSurfaceVariant = Color(0xFFEAE5DA)
val OnWarmSandVariant = Color(0xFF444842)
val SoftOutline = Color(0xFF757972)
val SoftOutlineVariant = Color(0xFFD5CFC4)

// Dark Palette - Deep Forest Charcoal & Soft Mint Sage
val SagePrimaryDark = Color(0xFF93D5B7)
val OnSagePrimaryDark = Color(0xFF003828)
val SagePrimaryContainerDark = Color(0xFF124634)
val OnSagePrimaryContainerDark = Color(0xFFAFEFD2)

val TerracottaSecondaryDark = Color(0xFFFFB59A)
val OnTerracottaSecondaryDark = Color(0xFF5C2109)
val TerracottaContainerDark = Color(0xFF7B3B1E)
val OnTerracottaContainerDark = Color(0xFFFFDBD0)

val AmberTertiaryDark = Color(0xFFF3BF5B)
val OnAmberTertiaryDark = Color(0xFF412D00)
val AmberTertiaryContainerDark = Color(0xFF5D4200)
val OnAmberTertiaryContainerDark = Color(0xFFFFDEA4)

val ForestBackgroundDark = Color(0xFF111512)
val OnForestBackgroundDark = Color(0xFFE3E4DE)
val ForestSurfaceDark = Color(0xFF171C18)
val ForestSurfaceVariantDark = Color(0xFF272E28)
val OnForestVariantDark = Color(0xFFC4C8C0)
val OutlineDark = Color(0xFF8E928B)
val OutlineVariantDark = Color(0xFF3E453E)

// Semantic Accents
val CautionContainerLight = Color(0xFFFCEAE8)
val OnCautionContainerLight = Color(0xFF7A1C16)
val CautionContainerDark = Color(0xFF4D1A17)
val OnCautionContainerDark = Color(0xFFFFDAD6)

val EvidenceContainerLight = Color(0xFFE3EFE9)
val OnEvidenceContainerLight = Color(0xFF164333)
val EvidenceContainerDark = Color(0xFF16382B)
val OnEvidenceContainerDark = Color(0xFFB7E5D0)
