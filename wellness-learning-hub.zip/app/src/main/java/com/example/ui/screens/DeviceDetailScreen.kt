package com.example.ui.screens

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Biotech
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Business
import androidx.compose.material.icons.outlined.ElectricBolt
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material.icons.outlined.SettingsSuggest
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material.icons.outlined.Waves
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.layout.ContentScale
import com.example.R
import com.example.data.WellnessDevice
import com.example.ui.components.AdaptiveContentBox
import com.example.ui.components.ExternalLinkOutlinedButton
import com.example.ui.components.MedicalDisclaimerCard
import com.example.ui.components.RemoteWellnessImage
import com.example.ui.components.openExternalUrl
import com.example.ui.theme.CautionContainerDark
import com.example.ui.theme.CautionContainerLight
import com.example.ui.theme.EvidenceContainerDark
import com.example.ui.theme.EvidenceContainerLight
import com.example.ui.theme.OnCautionContainerDark
import com.example.ui.theme.OnCautionContainerLight
import com.example.ui.theme.OnEvidenceContainerDark
import com.example.ui.theme.OnEvidenceContainerLight

@Composable
fun DeviceDetailScreen(
    device: WellnessDevice,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isDark = isSystemInDarkTheme()
    val evidenceBg = if (isDark) EvidenceContainerDark else EvidenceContainerLight
    val evidenceFg = if (isDark) OnEvidenceContainerDark else OnEvidenceContainerLight
    val cautionBg = if (isDark) CautionContainerDark else CautionContainerLight
    val cautionFg = if (isDark) OnCautionContainerDark else OnCautionContainerLight

    val deviceIcon = when (device.id) {
        "hot_house" -> Icons.Outlined.WbSunny
        "e_power" -> Icons.Outlined.Bolt
        "electro_reflex_energizer" -> Icons.Outlined.ElectricBolt
        "sun_ancon_chi_machine" -> Icons.Outlined.Waves
        else -> Icons.Outlined.Biotech
    }

    AdaptiveContentBox(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Nombre y 2. Fotografía oficial o espacio reservado
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "1. Equipo · ${device.name}",
                            style = MaterialTheme.typography.headlineMedium
                        )
                        Text(
                            text = device.subtitle,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary
                        )

                        RemoteWellnessImage(
                            imageUrl = device.officialImageUrl,
                            contentDescription = "Fotografía de ${device.name}",
                            fallbackTitle = device.name,
                            fallbackSubtitle = "Espacio reservado · Consulta fotografía en HTE / SOQI Universe",
                            fallbackIcon = deviceIcon,
                            fallbackDrawableRes = R.drawable.ic_fallback_device,
                            localAssetBasePath = device.localAssetBasePath,
                            remoteSourceLabel = "Fuente oficial verificada",
                            localSourceLabel = "Fotografía del equipo · Ref. SOQI Universe",
                            showProvenanceBadge = true,
                            aspectRatio = 16f / 9f,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.clip(MaterialTheme.shapes.medium)
                        )

                        Text(
                            text = "2. Fotografía oficial: ${device.officialVisualNote}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ExternalLinkOutlinedButton(
                                label = "HTE Global",
                                onClick = { openExternalUrl(context, device.officialProductUrl) },
                                testTag = "device_official_photo_link_${device.id}",
                                modifier = Modifier.weight(1f)
                            )
                            ExternalLinkOutlinedButton(
                                label = "SOQI Universe",
                                onClick = { openExternalUrl(context, device.secondarySourceUrl) },
                                testTag = "device_soqi_photo_link_${device.id}",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // 3. Descripción general & 4. Fabricante
            item {
                DeviceInfoCard(
                    icon = Icons.Outlined.Business,
                    title = "3. Descripción general y 4. Fabricante",
                    body = "${device.generalDescription}\n\nFabricante / empresa relacionada: ${device.manufacturer}"
                )
            }

            // 5. Tecnología utilizada & 6. Cómo funciona de forma sencilla
            item {
                DeviceInfoCard(
                    icon = Icons.Outlined.Lightbulb,
                    title = "5. Tecnología utilizada y 6. Cómo funciona",
                    body = "Tecnología: ${device.technologyUsed}\n\nExplicación sencilla: ${device.howItWorksSimple}"
                )
            }

            // 7. Características técnicas verificadas
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.SettingsSuggest,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "7. Características técnicas verificadas",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        device.verifiedSpecs.forEachIndexed { index, spec ->
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = spec.label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = spec.value,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            if (index < device.verifiedSpecs.lastIndex) {
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                            }
                        }
                    }
                }
            }

            // 8. Uso descrito por el fabricante
            item {
                DeviceInfoCard(
                    icon = Icons.Outlined.Verified,
                    title = "8. Uso descrito por el fabricante",
                    body = device.manufacturerUsage
                )
            }

            // 9. Investigaciones científicas & 10. Evidencia y sus limitaciones
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = evidenceBg)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Science,
                                contentDescription = null,
                                tint = evidenceFg
                            )
                            Text(
                                text = "9. Investigaciones y 10. Evidencia disponible y limitaciones",
                                style = MaterialTheme.typography.titleMedium,
                                color = evidenceFg,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "Investigaciones relacionadas:\n${device.relatedResearch}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = evidenceFg
                        )
                        HorizontalDivider(color = evidenceFg.copy(alpha = 0.2f))
                        Text(
                            text = "Alcance y limitaciones de la evidencia:\n${device.evidenceAndLimitations}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = evidenceFg
                        )
                    }
                }
            }

            // 11. Precauciones y contraindicaciones documentadas
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = cautionBg)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.WarningAmber,
                                contentDescription = "Precauciones y contraindicaciones",
                                tint = cautionFg
                            )
                            Text(
                                text = "11. Precauciones y contraindicaciones documentadas",
                                style = MaterialTheme.typography.titleMedium,
                                color = cautionFg,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        device.precautionsAndContraindications.forEach { bullet ->
                            Text(
                                text = "• $bullet",
                                style = MaterialTheme.typography.bodyMedium,
                                color = cautionFg
                            )
                        }
                    }
                }
            }

            // 12. Fuentes y referencias
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "12. Fuentes y referencias del equipo",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        device.sources.forEachIndexed { idx, source ->
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = source.title,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = source.organization,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                ExternalLinkOutlinedButton(
                                    label = "Abrir referencia",
                                    onClick = { openExternalUrl(context, source.url) },
                                    testTag = "device_source_${device.id}_$idx"
                                )
                            }
                        }
                    }
                }
            }

            item {
                MedicalDisclaimerCard()
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun DeviceInfoCard(
    icon: ImageVector,
    title: String,
    body: String,
    containerColor: Color = MaterialTheme.colorScheme.surface
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = body,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
