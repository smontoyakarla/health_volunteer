package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.outlined.AccessibilityNew
import androidx.compose.material.icons.outlined.Biotech
import androidx.compose.material.icons.outlined.Eco
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Restaurant
import androidx.compose.material.icons.outlined.Spa
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.WellnessSectionRoute
import com.example.ui.components.AdaptiveContentBox
import com.example.ui.components.MedicalDisclaimerCard
import com.example.ui.components.RemoteWellnessImage

import androidx.annotation.DrawableRes
import androidx.compose.foundation.layout.aspectRatio
import com.example.R

private data class HomeSectionVisual(
    val section: WellnessSectionRoute,
    val icon: ImageVector,
    val localAssetBasePath: String? = null,
    val remoteImageUrl: String? = null,
    val remoteAttribution: String? = null,
    val localSourceLabel: String = "Archivo local integrado",
    @DrawableRes val fallbackDrawableRes: Int? = null,
    val isAccentPrimary: Boolean = true
)

@Composable
fun HomeScreen(
    savedCount: Int,
    onOpenSection: (WellnessSectionRoute) -> Unit,
    onOpenBookmarks: () -> Unit,
    modifier: Modifier = Modifier
) {
    val homeSections = listOf(
        HomeSectionVisual(
            section = WellnessSectionRoute.VIDEOS,
            icon = Icons.Outlined.PlayCircle,
            localAssetBasePath = "images/inicio/inicio_videos",
            localSourceLabel = "Ilustración editorial de apoyo",
            fallbackDrawableRes = R.drawable.ic_fallback_video,
            isAccentPrimary = true
        ),
        HomeSectionVisual(
            section = WellnessSectionRoute.TECHNOLOGIES,
            icon = Icons.Outlined.Biotech,
            localAssetBasePath = "images/inicio/inicio_tecnologias",
            localSourceLabel = "Ilustración editorial de ambiente",
            fallbackDrawableRes = R.drawable.ic_fallback_device,
            isAccentPrimary = false
        ),
        HomeSectionVisual(
            section = WellnessSectionRoute.SUPERFOODS,
            icon = Icons.Outlined.Eco,
            localAssetBasePath = "images/inicio/inicio_superalimentos",
            remoteImageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Curcuma_longa_001.JPG?width=800",
            remoteAttribution = "Wikimedia Commons · Curcuma longa",
            fallbackDrawableRes = R.drawable.ic_fallback_ingredient,
            isAccentPrimary = true
        ),
        HomeSectionVisual(
            section = WellnessSectionRoute.NUTRITION,
            icon = Icons.Outlined.Restaurant,
            localAssetBasePath = "images/inicio/inicio_nutricion",
            remoteImageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Vegetables.jpg?width=800",
            remoteAttribution = "Wikimedia Commons · Vegetales frescos",
            fallbackDrawableRes = R.drawable.ic_fallback_nutrition,
            isAccentPrimary = false
        ),
        HomeSectionVisual(
            section = WellnessSectionRoute.MOVEMENT,
            icon = Icons.Outlined.AccessibilityNew,
            localAssetBasePath = "images/inicio/inicio_movimiento",
            remoteImageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Yoga.JPG?width=800",
            remoteAttribution = "Wikimedia Commons · Práctica de yoga",
            fallbackDrawableRes = R.drawable.ic_fallback_movement,
            isAccentPrimary = true
        ),
        HomeSectionVisual(
            section = WellnessSectionRoute.COMMUNITY,
            icon = Icons.Outlined.Groups,
            localAssetBasePath = "images/inicio/inicio_comunidad",
            localSourceLabel = "Ilustración editorial de apoyo",
            isAccentPrimary = false
        ),
        HomeSectionVisual(
            section = WellnessSectionRoute.SOURCES,
            icon = Icons.AutoMirrored.Outlined.MenuBook,
            localAssetBasePath = "images/inicio/inicio_fuentes",
            localSourceLabel = "Ilustración editorial de apoyo",
            isAccentPrimary = true
        )
    )

    AdaptiveContentBox(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                HomeHeaderSection(
                    savedCount = savedCount,
                    onOpenBookmarks = onOpenBookmarks
                )
            }

            item {
                HomeHeroBanner(
                    onExploreTech = { onOpenSection(WellnessSectionRoute.TECHNOLOGIES) }
                )
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Explora las 7 áreas educativas",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "7 módulos",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            items(homeSections, key = { it.section.route }) { item ->
                HomeSectionCard(
                    item = item,
                    onClick = { onOpenSection(item.section) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
                MedicalDisclaimerCard()
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun HomeHeaderSection(
    savedCount: Int,
    onOpenBookmarks: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(32.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Outlined.Spa,
                            contentDescription = "Logotipo Wellness Learning Hub",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Text(
                    text = "Plataforma educativa",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Text(
                text = "Wellness Learning Hub",
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Bienestar integral, tecnologías HTE, superalimentos, nutrición, movimiento y evidencia en español de México.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Surface(
            onClick = onOpenBookmarks,
            shape = RoundedCornerShape(50),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .testTag("home_bookmarks_button")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Bookmark,
                    contentDescription = "Elementos guardados",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "$savedCount",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun HomeHeroBanner(
    onExploreTech: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clickable(onClick = onExploreTech)
            .testTag("home_hero_banner"),
        shape = MaterialTheme.shapes.large,
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            RemoteWellnessImage(
                imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Mediterranean_diet.jpg?width=900",
                contentDescription = "Fotografía real de alimentos frescos naturales y hábitos de bienestar",
                fallbackTitle = "Wellness Learning Hub",
                fallbackSubtitle = "Educación preventiva basada en evidencia y fuentes abiertas",
                fallbackIcon = Icons.Outlined.Spa,
                localAssetBasePath = "images/inicio/inicio_hero_bienestar",
                remoteSourceLabel = "Wikimedia Commons · Dieta natural",
                aspectRatio = 16f / 9f,
                modifier = Modifier.fillMaxSize(),
                targetWidthPx = 900,
                targetHeightPx = 506
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xD9112A20),
                                Color(0x99112A20),
                                Color(0x33112A20)
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.tertiaryContainer
                ) {
                    Text(
                        text = "Enfoque basado en educación y prevención",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
                Text(
                    text = "Aprende con criterio claro y fuentes abiertas",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
                Text(
                    text = "Explora fichas técnicas de 12 puntos, rutinas guiadas y hábitos sostenibles.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.92f)
                )
            }
        }
    }
}

@Composable
private fun HomeSectionCard(
    item: HomeSectionVisual,
    onClick: () -> Unit
) {
    val containerColor = MaterialTheme.colorScheme.surface
    val iconBg = if (item.isAccentPrimary) {
        MaterialTheme.colorScheme.primaryContainer
    } else {
        MaterialTheme.colorScheme.secondaryContainer
    }
    val iconTint = if (item.isAccentPrimary) {
        MaterialTheme.colorScheme.onPrimaryContainer
    } else {
        MaterialTheme.colorScheme.onSecondaryContainer
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag("home_section_${item.section.route}"),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column {
            if (item.remoteImageUrl != null || item.localAssetBasePath != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                ) {
                    RemoteWellnessImage(
                        imageUrl = item.remoteImageUrl,
                        contentDescription = item.section.title,
                        fallbackTitle = item.section.title,
                        fallbackSubtitle = item.section.badge,
                        fallbackIcon = item.icon,
                        fallbackDrawableRes = item.fallbackDrawableRes,
                        localAssetBasePath = item.localAssetBasePath,
                        remoteSourceLabel = item.remoteAttribution,
                        localSourceLabel = item.localSourceLabel,
                        aspectRatio = 16f / 9f,
                        modifier = Modifier.fillMaxSize(),
                        targetWidthPx = 800,
                        targetHeightPx = 450
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.45f))
                                )
                            )
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                        shape = RoundedCornerShape(50),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = item.section.badge,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = iconBg,
                    modifier = Modifier.size(48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = null,
                            tint = iconTint,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    if (item.remoteImageUrl == null) {
                        Text(
                            text = item.section.badge,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(
                        text = item.section.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = item.section.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Ir a ${item.section.title}",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
