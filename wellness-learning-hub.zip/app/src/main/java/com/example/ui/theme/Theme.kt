package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val WellnessDarkColorScheme = darkColorScheme(
    primary = SagePrimaryDark,
    onPrimary = OnSagePrimaryDark,
    primaryContainer = SagePrimaryContainerDark,
    onPrimaryContainer = OnSagePrimaryContainerDark,
    secondary = TerracottaSecondaryDark,
    onSecondary = OnTerracottaSecondaryDark,
    secondaryContainer = TerracottaContainerDark,
    onSecondaryContainer = OnTerracottaContainerDark,
    tertiary = AmberTertiaryDark,
    onTertiary = OnAmberTertiaryDark,
    tertiaryContainer = AmberTertiaryContainerDark,
    onTertiaryContainer = OnAmberTertiaryContainerDark,
    background = ForestBackgroundDark,
    onBackground = OnForestBackgroundDark,
    surface = ForestSurfaceDark,
    onSurface = OnForestBackgroundDark,
    surfaceVariant = ForestSurfaceVariantDark,
    onSurfaceVariant = OnForestVariantDark,
    outline = OutlineDark,
    outlineVariant = OutlineVariantDark
)

private val WellnessLightColorScheme = lightColorScheme(
    primary = SagePrimary,
    onPrimary = OnSagePrimary,
    primaryContainer = SagePrimaryContainer,
    onPrimaryContainer = OnSagePrimaryContainer,
    secondary = TerracottaSecondary,
    onSecondary = OnTerracottaSecondary,
    secondaryContainer = TerracottaContainer,
    onSecondaryContainer = OnTerracottaContainer,
    tertiary = AmberTertiary,
    onTertiary = OnAmberTertiary,
    tertiaryContainer = AmberTertiaryContainer,
    onTertiaryContainer = OnAmberTertiaryContainer,
    background = CreamBackground,
    onBackground = OnCreamBackground,
    surface = CreamSurface,
    onSurface = OnCreamSurface,
    surfaceVariant = WarmSandSurfaceVariant,
    onSurfaceVariant = OnWarmSandVariant,
    outline = SoftOutline,
    outlineVariant = SoftOutlineVariant
)

val WellnessShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun WellnessHubTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) WellnessDarkColorScheme else WellnessLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = WellnessTypography,
        shapes = WellnessShapes,
        content = content
    )
}
