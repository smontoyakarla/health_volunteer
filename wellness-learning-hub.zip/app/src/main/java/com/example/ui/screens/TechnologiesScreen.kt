package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.outlined.Biotech
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.ElectricBolt
import androidx.compose.material.icons.outlined.HealthAndSafety
import androidx.compose.material.icons.outlined.Waves
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.ui.layout.ContentScale
import com.example.R
import com.example.data.WellnessDevice
import com.example.ui.components.AdaptiveContentBox
import com.example.ui.components.BookmarkToggleButton
import com.example.ui.components.ExternalLinkOutlinedButton
import com.example.ui.components.MedicalDisclaimerCard
import com.example.ui.components.RemoteWellnessImage
import com.example.ui.components.openExternalUrl

private fun deviceIconFor(deviceId: String): ImageVector = when (deviceId) {
    "hot_house" -> Icons.Outlined.WbSunny
    "e_power" -> Icons.Outlined.Bolt
    "electro_reflex_energizer" -> Icons.Outlined.ElectricBolt
    "sun_ancon_chi_machine" -> Icons.Outlined.Waves
    else -> Icons.Outlined.Biotech
}

@Composable
fun TechnologiesScreen(
    devices: List<WellnessDevice>,
    savedIds: Set<String>,
    onOpenDevice: (String) -> Unit,
    onToggleBookmark: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    AdaptiveContentBox(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Tecnologías de bienestar · Fuentes oficiales",
                            style = MaterialTheme.typography.headlineSmall
                        )
                        Text(
                            text = "Análisis objetivo de equipos utilizados en campañas comunitarias: funcionamiento, especificaciones, evidencia, limitaciones y contraindicaciones. Cada aparato muestra su fotografía individual proporcionada y enlaces a las fuentes oficiales.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ExternalLinkOutlinedButton(
                                label = "hteglobal.com",
                                onClick = { openExternalUrl(context, "https://www.hteglobal.com/") },
                                testTag = "hte_global_website_button",
                                modifier = Modifier.weight(1f)
                            )
                            ExternalLinkOutlinedButton(
                                label = "soqiuniverse.com",
                                onClick = { openExternalUrl(context, "https://www.soqiuniverse.com/") },
                                testTag = "soqi_universe_website_button",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            items(devices, key = { it.id }) { device ->
                DeviceSummaryCard(
                    device = device,
                    isSaved = device.id in savedIds,
                    onOpen = { onOpenDevice(device.id) },
                    onOpenOfficialSource = { openExternalUrl(context, device.secondarySourceUrl) },
                    onToggleBookmark = { onToggleBookmark(device.id) }
                )
            }

            item {
                MedicalDisclaimerCard()
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun DeviceSummaryCard(
    device: WellnessDevice,
    isSaved: Boolean,
    onOpen: () -> Unit,
    onOpenOfficialSource: () -> Unit,
    onToggleBookmark: () -> Unit
) {
    val icon = deviceIconFor(device.id)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clip(MaterialTheme.shapes.large)
            .clickable(onClick = onOpen)
            .testTag("device_card_${device.id}"),
        shape = MaterialTheme.shapes.large,
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            RemoteWellnessImage(
                imageUrl = device.officialImageUrl,
                contentDescription = "Fotografía de ${device.name}",
                fallbackTitle = device.name,
                fallbackSubtitle = "Espacio reservado · Consulta fotografía oficial en HTE / SOQI Universe",
                fallbackIcon = icon,
                fallbackDrawableRes = R.drawable.ic_fallback_device,
                localAssetBasePath = device.localAssetBasePath,
                remoteSourceLabel = "Fuente oficial verificada",
                localSourceLabel = "Fotografía del equipo · Ref. SOQI Universe",
                showProvenanceBadge = true,
                aspectRatio = 16f / 9f,
                contentScale = ContentScale.Fit
            )

            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = device.subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        Text(
                            text = device.name,
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    BookmarkToggleButton(
                        isSaved = isSaved,
                        onToggle = onToggleBookmark,
                        testTag = "bookmark_device_${device.id}"
                    )
                }

                Text(
                    text = device.generalDescription,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.HealthAndSafety,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "${device.precautionsAndContraindications.size} precauciones documentadas",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }

                ExternalLinkOutlinedButton(
                    label = "Ver equipo en fuente oficial",
                    onClick = onOpenOfficialSource,
                    testTag = "device_list_source_${device.id}",
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Abrir ficha completa (12 puntos)",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Ver ficha de ${device.name}",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}
