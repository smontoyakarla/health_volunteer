package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BookmarkEntry
import com.example.data.BookmarksPreferences
import com.example.data.CommunityLearning
import com.example.data.CommunityStation
import com.example.data.EducationalVideo
import com.example.data.MovementRoutine
import com.example.data.NutritionTopic
import com.example.data.ScientificSource
import com.example.data.SourceCategory
import com.example.data.SuperfoodCategory
import com.example.data.SuperfoodItem
import com.example.data.VideoCategory
import com.example.data.VideoChannel
import com.example.data.WellnessDevice
import com.example.data.WellnessRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class WellnessUiState(
    val videos: List<EducationalVideo> = emptyList(),
    val selectedChannel: VideoChannel? = null,
    val selectedVideoCategory: VideoCategory = VideoCategory.ALL,
    val videoSearchQuery: String = "",
    val devices: List<WellnessDevice> = emptyList(),
    val superfoods: List<SuperfoodItem> = emptyList(),
    val selectedSuperfoodCategory: SuperfoodCategory = SuperfoodCategory.ALL,
    val nutritionTopics: List<NutritionTopic> = emptyList(),
    val movementRoutines: List<MovementRoutine> = emptyList(),
    val communityIntro: String = "",
    val communityStations: List<CommunityStation> = emptyList(),
    val communityLearnings: List<CommunityLearning> = emptyList(),
    val sources: List<ScientificSource> = emptyList(),
    val selectedSourceCategory: SourceCategory = SourceCategory.ALL,
    val savedIds: Set<String> = emptySet(),
    val savedBookmarks: List<BookmarkEntry> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = WellnessRepository()
    private val bookmarksPreferences = BookmarksPreferences(application.applicationContext)

    private val selectedChannel = MutableStateFlow<VideoChannel?>(null)
    private val selectedVideoCategory = MutableStateFlow(VideoCategory.ALL)
    private val videoSearchQuery = MutableStateFlow("")
    private val selectedSuperfoodCategory = MutableStateFlow(SuperfoodCategory.ALL)
    private val selectedSourceCategory = MutableStateFlow(SourceCategory.ALL)

    private val allVideos = repository.getVideos()
    private val allDevices = repository.getDevices()
    private val allSuperfoods = repository.getSuperfoods()
    private val allNutrition = repository.getNutritionTopics()
    private val allMovement = repository.getMovementRoutines()
    private val allSources = repository.getSources()
    private val bookmarkIndex = repository.getAllBookmarkableEntries()

    private val filterFlow = combine(
        selectedChannel,
        selectedVideoCategory,
        videoSearchQuery,
        selectedSuperfoodCategory,
        selectedSourceCategory
    ) { channel, videoCat, query, superfoodCat, sourceCat ->
        FilterParams(channel, videoCat, query, superfoodCat, sourceCat)
    }

    val uiState: StateFlow<WellnessUiState> = combine(
        filterFlow,
        bookmarksPreferences.savedIdsFlow
    ) { filters, savedIds ->
        val filteredVideos = allVideos.filter { video ->
            val matchesChannel = filters.channel == null || video.channel == filters.channel
            val matchesCat = filters.videoCat == VideoCategory.ALL || video.category == filters.videoCat
            val trimmed = filters.query.trim()
            val matchesQuery = trimmed.isEmpty() ||
                video.title.contains(trimmed, ignoreCase = true) ||
                video.focusSummary.contains(trimmed, ignoreCase = true) ||
                video.category.label.contains(trimmed, ignoreCase = true) ||
                video.channel.displayName.contains(trimmed, ignoreCase = true)
            matchesChannel && matchesCat && matchesQuery
        }

        val filteredSuperfoods = allSuperfoods.filter { item ->
            filters.superfoodCat == SuperfoodCategory.ALL || item.category == filters.superfoodCat
        }

        val filteredSources = allSources.filter { source ->
            filters.sourceCat == SourceCategory.ALL || source.category == filters.sourceCat
        }

        val savedEntries = savedIds.mapNotNull { bookmarkIndex[it] }

        WellnessUiState(
            videos = filteredVideos,
            selectedChannel = filters.channel,
            selectedVideoCategory = filters.videoCat,
            videoSearchQuery = filters.query,
            devices = allDevices,
            superfoods = filteredSuperfoods,
            selectedSuperfoodCategory = filters.superfoodCat,
            nutritionTopics = allNutrition,
            movementRoutines = allMovement,
            communityIntro = repository.getCommunityIntro(),
            communityStations = repository.getCommunityStations(),
            communityLearnings = repository.getCommunityLearnings(),
            sources = filteredSources,
            selectedSourceCategory = filters.sourceCat,
            savedIds = savedIds,
            savedBookmarks = savedEntries
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = WellnessUiState(
            videos = allVideos,
            devices = allDevices,
            superfoods = allSuperfoods,
            nutritionTopics = allNutrition,
            movementRoutines = allMovement,
            communityIntro = repository.getCommunityIntro(),
            communityStations = repository.getCommunityStations(),
            communityLearnings = repository.getCommunityLearnings(),
            sources = allSources
        )
    )

    fun selectVideoChannel(channel: VideoChannel?) {
        selectedChannel.value = channel
    }

    fun selectVideoCategory(category: VideoCategory) {
        selectedVideoCategory.value = category
    }

    fun updateVideoSearchQuery(query: String) {
        videoSearchQuery.value = query
    }

    fun selectSuperfoodCategory(category: SuperfoodCategory) {
        selectedSuperfoodCategory.value = category
    }

    fun selectSourceCategory(category: SourceCategory) {
        selectedSourceCategory.value = category
    }

    fun toggleBookmark(itemId: String) {
        viewModelScope.launch {
            bookmarksPreferences.toggleBookmark(itemId)
        }
    }

    fun getDeviceById(deviceId: String): WellnessDevice? = repository.getDeviceById(deviceId)

    private data class FilterParams(
        val channel: VideoChannel?,
        val videoCat: VideoCategory,
        val query: String,
        val superfoodCat: SuperfoodCategory,
        val sourceCat: SourceCategory
    )
}
