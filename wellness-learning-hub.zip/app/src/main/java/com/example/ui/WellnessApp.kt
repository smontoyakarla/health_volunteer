package com.example.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Biotech
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.outlined.Biotech
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Restaurant
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.WellnessSectionRoute
import com.example.ui.components.BookmarkToggleButton
import com.example.ui.components.WellnessScreenTopBar
import com.example.ui.screens.BookmarksScreen
import com.example.ui.screens.CommunityExperienceScreen
import com.example.ui.screens.DeviceDetailScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MovementScreen
import com.example.ui.screens.NutritionScreen
import com.example.ui.screens.SourcesScreen
import com.example.ui.screens.SuperfoodsScreen
import com.example.ui.screens.TechnologiesScreen
import com.example.ui.screens.VideosScreen

object AppRoutes {
    const val HOME = "home"
    const val BOOKMARKS = "bookmarks"
    const val DEVICE_DETAIL = "device_detail/{deviceId}"

    fun deviceDetail(deviceId: String): String = "device_detail/$deviceId"
}

private data class TopNavItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

@Composable
fun WellnessApp(
    viewModel: MainViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: AppRoutes.HOME

    val topNavItems = listOf(
        TopNavItem(
            route = AppRoutes.HOME,
            label = "Inicio",
            selectedIcon = Icons.Filled.Home,
            unselectedIcon = Icons.Outlined.Home
        ),
        TopNavItem(
            route = WellnessSectionRoute.VIDEOS.route,
            label = "Videos",
            selectedIcon = Icons.Filled.PlayCircle,
            unselectedIcon = Icons.Outlined.PlayCircle
        ),
        TopNavItem(
            route = WellnessSectionRoute.TECHNOLOGIES.route,
            label = "Equipos",
            selectedIcon = Icons.Filled.Biotech,
            unselectedIcon = Icons.Outlined.Biotech
        ),
        TopNavItem(
            route = WellnessSectionRoute.NUTRITION.route,
            label = "Nutrición",
            selectedIcon = Icons.Filled.Restaurant,
            unselectedIcon = Icons.Outlined.Restaurant
        ),
        TopNavItem(
            route = AppRoutes.BOOKMARKS,
            label = "Guardados",
            selectedIcon = Icons.Filled.Bookmark,
            unselectedIcon = Icons.Outlined.BookmarkBorder
        )
    )

    val navigateTopLevel: (String) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    val isTopLevelRoute = currentRoute in topNavItems.map { it.route }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                when {
                    currentRoute == AppRoutes.HOME -> Unit
                    currentRoute == WellnessSectionRoute.VIDEOS.route -> {
                        WellnessScreenTopBar(
                            title = WellnessSectionRoute.VIDEOS.title,
                            subtitle = "Tone and Tighten · GAIAM",
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                    currentRoute == WellnessSectionRoute.TECHNOLOGIES.route -> {
                        WellnessScreenTopBar(
                            title = WellnessSectionRoute.TECHNOLOGIES.title,
                            subtitle = "Equipos HTE International",
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                    currentRoute.startsWith("device_detail/") -> {
                        val deviceId = backStackEntry?.arguments?.getString("deviceId") ?: ""
                        val device = viewModel.getDeviceById(deviceId)
                        WellnessScreenTopBar(
                            title = device?.name ?: "Ficha del equipo",
                            subtitle = "Ficha educativa de 12 puntos",
                            onNavigateBack = { navController.popBackStack() },
                            actions = {
                                if (device != null) {
                                    BookmarkToggleButton(
                                        isSaved = device.id in uiState.savedIds,
                                        onToggle = { viewModel.toggleBookmark(device.id) },
                                        testTag = "bookmark_device_detail_${device.id}"
                                    )
                                }
                            }
                        )
                    }
                    currentRoute == WellnessSectionRoute.SUPERFOODS.route -> {
                        WellnessScreenTopBar(
                            title = WellnessSectionRoute.SUPERFOODS.title,
                            subtitle = "Hongos, raíces, semillas y algas",
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                    currentRoute == WellnessSectionRoute.NUTRITION.route -> {
                        WellnessScreenTopBar(
                            title = WellnessSectionRoute.NUTRITION.title,
                            subtitle = "Guías prácticas y etiquetado",
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                    currentRoute == WellnessSectionRoute.MOVEMENT.route -> {
                        WellnessScreenTopBar(
                            title = WellnessSectionRoute.MOVEMENT.title,
                            subtitle = "Rutinas seguras paso a paso",
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                    currentRoute == WellnessSectionRoute.COMMUNITY.route -> {
                        WellnessScreenTopBar(
                            title = WellnessSectionRoute.COMMUNITY.title,
                            subtitle = "Metodología y portafolio",
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                    currentRoute == WellnessSectionRoute.SOURCES.route -> {
                        WellnessScreenTopBar(
                            title = WellnessSectionRoute.SOURCES.title,
                            subtitle = "Salud pública y evidencia",
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                    currentRoute == AppRoutes.BOOKMARKS -> {
                        WellnessScreenTopBar(
                            title = "Elementos guardados",
                            subtitle = "${uiState.savedBookmarks.size} en tu biblioteca",
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                }
            },
            bottomBar = {
                if (!useRail && isTopLevelRoute) {
                    NavigationBar(
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        topNavItems.forEach { item ->
                            val selected = currentRoute == item.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopLevel(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label
                                    )
                                },
                                label = { Text(item.label) },
                                modifier = Modifier.testTag("bottom_nav_${item.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail && isTopLevelRoute) {
                    NavigationRail(
                        modifier = Modifier.windowInsetsPadding(WindowInsets.statusBars)
                    ) {
                        topNavItems.forEach { item ->
                            val selected = currentRoute == item.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopLevel(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label
                                    )
                                },
                                label = { Text(item.label) }
                            )
                        }
                    }
                }

                val contentModifier = if (currentRoute == AppRoutes.HOME) {
                    Modifier
                        .fillMaxSize()
                        .windowInsetsPadding(WindowInsets.statusBars)
                } else {
                    Modifier.fillMaxSize()
                }

                Box(modifier = contentModifier) {
                    NavHost(
                        navController = navController,
                        startDestination = AppRoutes.HOME
                    ) {
                        composable(AppRoutes.HOME) {
                            HomeScreen(
                                savedCount = uiState.savedBookmarks.size,
                                onOpenSection = { section ->
                                    navController.navigate(section.route) {
                                        launchSingleTop = true
                                    }
                                },
                                onOpenBookmarks = {
                                    navController.navigate(AppRoutes.BOOKMARKS) {
                                        launchSingleTop = true
                                    }
                                }
                            )
                        }

                        composable(WellnessSectionRoute.VIDEOS.route) {
                            VideosScreen(
                                videos = uiState.videos,
                                selectedChannel = uiState.selectedChannel,
                                selectedCategory = uiState.selectedVideoCategory,
                                searchQuery = uiState.videoSearchQuery,
                                savedIds = uiState.savedIds,
                                onSelectChannel = viewModel::selectVideoChannel,
                                onSelectCategory = viewModel::selectVideoCategory,
                                onSearchQueryChange = viewModel::updateVideoSearchQuery,
                                onToggleBookmark = viewModel::toggleBookmark
                            )
                        }

                        composable(WellnessSectionRoute.TECHNOLOGIES.route) {
                            TechnologiesScreen(
                                devices = uiState.devices,
                                savedIds = uiState.savedIds,
                                onOpenDevice = { deviceId ->
                                    navController.navigate(AppRoutes.deviceDetail(deviceId))
                                },
                                onToggleBookmark = viewModel::toggleBookmark
                            )
                        }

                        composable(
                            route = AppRoutes.DEVICE_DETAIL,
                            arguments = listOf(navArgument("deviceId") { type = NavType.StringType })
                        ) { entry ->
                            val deviceId = entry.arguments?.getString("deviceId").orEmpty()
                            val device = viewModel.getDeviceById(deviceId)
                            if (device != null) {
                                DeviceDetailScreen(device = device)
                            }
                        }

                        composable(WellnessSectionRoute.SUPERFOODS.route) {
                            SuperfoodsScreen(
                                items = uiState.superfoods,
                                selectedCategory = uiState.selectedSuperfoodCategory,
                                savedIds = uiState.savedIds,
                                onSelectCategory = viewModel::selectSuperfoodCategory,
                                onToggleBookmark = viewModel::toggleBookmark
                            )
                        }

                        composable(WellnessSectionRoute.NUTRITION.route) {
                            NutritionScreen(
                                topics = uiState.nutritionTopics,
                                savedIds = uiState.savedIds,
                                onToggleBookmark = viewModel::toggleBookmark
                            )
                        }

                        composable(WellnessSectionRoute.MOVEMENT.route) {
                            MovementScreen(
                                routines = uiState.movementRoutines,
                                savedIds = uiState.savedIds,
                                onToggleBookmark = viewModel::toggleBookmark,
                                onOpenRelatedVideos = { category ->
                                    viewModel.selectVideoCategory(category)
                                    navController.navigate(WellnessSectionRoute.VIDEOS.route) {
                                        launchSingleTop = true
                                    }
                                }
                            )
                        }

                        composable(WellnessSectionRoute.COMMUNITY.route) {
                            CommunityExperienceScreen(
                                intro = uiState.communityIntro,
                                stations = uiState.communityStations,
                                learnings = uiState.communityLearnings
                            )
                        }

                        composable(WellnessSectionRoute.SOURCES.route) {
                            SourcesScreen(
                                sources = uiState.sources,
                                selectedCategory = uiState.selectedSourceCategory,
                                onSelectCategory = viewModel::selectSourceCategory
                            )
                        }

                        composable(AppRoutes.BOOKMARKS) {
                            BookmarksScreen(
                                bookmarks = uiState.savedBookmarks,
                                onOpenRoute = { target ->
                                    navController.navigate(target) {
                                        launchSingleTop = true
                                    }
                                },
                                onToggleBookmark = viewModel::toggleBookmark
                            )
                        }
                    }
                }
            }
        }
    }
}
