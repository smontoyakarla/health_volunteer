package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.ScientificSource
import com.example.data.SourceCategory
import com.example.ui.components.AdaptiveContentBox
import com.example.ui.components.ExternalLinkOutlinedButton
import com.example.ui.components.MedicalDisclaimerCard
import com.example.ui.components.openExternalUrl

@Composable
fun SourcesScreen(
    sources: List<ScientificSource>,
    selectedCategory: SourceCategory,
    onSelectCategory: (SourceCategory) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    AdaptiveContentBox(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Fuentes y referencias abiertas",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        text = "Directorio de organismos públicos de salud, bases biomédicas, canales educativos de fisioterapia/yoga y documentación oficial de fabricantes.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(SourceCategory.entries) { category ->
                        FilterChip(
                            selected = selectedCategory == category,
                            onClick = { onSelectCategory(category) },
                            label = { Text(category.label) },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("source_cat_${category.name}")
                        )
                    }
                }
            }

            items(sources, key = { it.id }) { source ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("source_card_${source.id}"),
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = source.category.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        Text(
                            text = source.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = source.organization,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = source.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        ExternalLinkOutlinedButton(
                            label = "Consultar sitio oficial",
                            onClick = { openExternalUrl(context, source.url) },
                            testTag = "open_source_${source.id}"
                        )
                    }
                }
            }

            item {
                MedicalDisclaimerCard()
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}
