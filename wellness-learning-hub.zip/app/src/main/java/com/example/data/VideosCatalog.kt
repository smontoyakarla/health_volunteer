package com.example.data

object VideosCatalog {
    val videos: List<EducationalVideo> = listOf(
        // Tone and Tighten (sin inventar VIDEO_IDs; apoyo ilustrativo temático cuando no hay miniatura verificada)
        EducationalVideo(
            id = "tt_neck_shoulders",
            title = "Rutina guiada de estiramiento para cuello, hombros y espalda alta",
            channel = VideoChannel.TONE_AND_TIGHTEN,
            category = VideoCategory.NECK_SHOULDERS,
            focusSummary = "Secuencia suave enfocada en liberar tensión cervical y trapecios por trabajo frente a pantalla.",
            viewsNote = "Visualizaciones e ID verificables en YouTube",
            localAssetBasePath = "images/videos/video_tt_neck_shoulders",
            youtubeVideoId = null,
            illustrativeImageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Neck_exercises.jpg?width=800",
            illustrativeAttribution = "Imagen ilustrativa temática · Wikimedia Commons",
            videoUrl = "https://www.youtube.com/@toneandtighten/search?query=neck+shoulders+upper+back+stretch",
            channelUrl = VideoChannel.TONE_AND_TIGHTEN.channelUrl,
            estimatedDuration = "Búsqueda temática · ~5–10 min"
        ),
        EducationalVideo(
            id = "tt_lower_back",
            title = "Estiramientos y movilidad suave para zona lumbar y espalda baja",
            channel = VideoChannel.TONE_AND_TIGHTEN,
            category = VideoCategory.BACK,
            focusSummary = "Movimientos controlados de inclinación pélvica y flexión suave explicados por fisioterapeuta.",
            viewsNote = "Visualizaciones e ID verificables en YouTube",
            localAssetBasePath = "images/videos/video_tt_lower_back",
            youtubeVideoId = null,
            illustrativeImageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Pilates-back-stretch.jpg?width=800",
            illustrativeAttribution = "Imagen ilustrativa temática · Wikimedia Commons",
            videoUrl = "https://www.youtube.com/@toneandtighten/search?query=lower+back+stretch+relief",
            channelUrl = VideoChannel.TONE_AND_TIGHTEN.channelUrl,
            estimatedDuration = "Búsqueda temática · ~8–12 min"
        ),
        EducationalVideo(
            id = "tt_knees_strength",
            title = "Fortalecimiento muscular y cuidado progresivo para rodillas",
            channel = VideoChannel.TONE_AND_TIGHTEN,
            category = VideoCategory.KNEES,
            focusSummary = "Ejercicios de bajo impacto para cuádriceps, glúteo medio y estabilidad articular de rodilla.",
            viewsNote = "Visualizaciones e ID verificables en YouTube",
            localAssetBasePath = "images/videos/video_tt_knees_strength",
            youtubeVideoId = null,
            illustrativeImageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Squatting.jpg?width=800",
            illustrativeAttribution = "Imagen ilustrativa temática · Wikimedia Commons",
            videoUrl = "https://www.youtube.com/@toneandtighten/search?query=knee+strengthening+exercises",
            channelUrl = VideoChannel.TONE_AND_TIGHTEN.channelUrl,
            estimatedDuration = "Búsqueda temática · ~10 min"
        ),
        EducationalVideo(
            id = "tt_full_body_stretch",
            title = "Estiramiento diario de cuerpo completo para rigidez muscular y movilidad",
            channel = VideoChannel.TONE_AND_TIGHTEN,
            category = VideoCategory.STRETCHING,
            focusSummary = "Rutina integral para principiantes orientada a recuperar rango de movimiento tras estar sentado.",
            viewsNote = "Visualizaciones e ID verificables en YouTube",
            localAssetBasePath = "images/videos/video_tt_full_body_stretch",
            youtubeVideoId = null,
            illustrativeImageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Mr-yoga-shoulder_stretch_1.jpg?width=800",
            illustrativeAttribution = "Imagen ilustrativa temática · Wikimedia Commons",
            videoUrl = "https://www.youtube.com/@toneandtighten/search?query=total+body+stretch+flexibility",
            channelUrl = VideoChannel.TONE_AND_TIGHTEN.channelUrl,
            estimatedDuration = "Búsqueda temática · ~10 min"
        ),
        EducationalVideo(
            id = "tt_core_strength",
            title = "Fortalecimiento básico de zona media (core) y estabilidad postural",
            channel = VideoChannel.TONE_AND_TIGHTEN,
            category = VideoCategory.STRENGTH,
            focusSummary = "Activación profunda del abdomen y musculatura estabilizadora sin sobrecargar el cuello.",
            viewsNote = "Visualizaciones e ID verificables en YouTube",
            localAssetBasePath = "images/videos/video_tt_core_strength",
            youtubeVideoId = null,
            illustrativeImageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Side_Plank.jpg?width=800",
            illustrativeAttribution = "Imagen ilustrativa temática · Wikimedia Commons",
            videoUrl = "https://www.youtube.com/@toneandtighten/search?query=beginner+core+strengthening",
            channelUrl = VideoChannel.TONE_AND_TIGHTEN.channelUrl,
            estimatedDuration = "Búsqueda temática · ~10–15 min"
        ),

        // GAIAM (sin inventar VIDEO_IDs; apoyo ilustrativo temático cuando no hay miniatura verificada)
        EducationalVideo(
            id = "gaiam_foam_roller",
            title = "Uso de rodillo de masaje (foam roller) para recuperación corporal",
            channel = VideoChannel.GAIAM,
            category = VideoCategory.FOAM_ROLLER,
            focusSummary = "Guía visual sobre liberación miofascial en espalda dorsal, muslos y pantorrillas.",
            viewsNote = "Visualizaciones e ID verificables en YouTube",
            localAssetBasePath = "images/videos/video_gaiam_foam_roller",
            youtubeVideoId = null,
            illustrativeImageUrl = null,
            illustrativeAttribution = "Ilustración temática de apoyo · Uso educativo",
            videoUrl = "https://www.youtube.com/@gaiam/search?query=foam+roller",
            channelUrl = VideoChannel.GAIAM.channelUrl,
            estimatedDuration = "Búsqueda temática · ~10–15 min"
        ),
        EducationalVideo(
            id = "gaiam_yoga_beginners",
            title = "Sesión de yoga suave para principiantes y respiración consciente",
            channel = VideoChannel.GAIAM,
            category = VideoCategory.YOGA,
            focusSummary = "Posturas fundamentales de yoga adaptables con bloques o tapete para mejorar la calma y postura.",
            viewsNote = "Visualizaciones e ID verificables en YouTube",
            localAssetBasePath = "images/videos/video_gaiam_yoga_beginners",
            youtubeVideoId = null,
            illustrativeImageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Downward-Facing-Dog.JPG?width=800",
            illustrativeAttribution = "Imagen ilustrativa temática · Wikimedia Commons",
            videoUrl = "https://www.youtube.com/@gaiam/search?query=beginner+yoga",
            channelUrl = VideoChannel.GAIAM.channelUrl,
            estimatedDuration = "Búsqueda temática · ~15–20 min"
        ),
        EducationalVideo(
            id = "gaiam_hip_mobility",
            title = "Movilidad de cadera y apertura muscular para aliviar rigidez",
            channel = VideoChannel.GAIAM,
            category = VideoCategory.MOBILITY,
            focusSummary = "Transiciones fluidas enfocadas en flexores de cadera, piriforme y movilidad pélvica.",
            viewsNote = "Visualizaciones e ID verificables en YouTube",
            localAssetBasePath = "images/videos/video_gaiam_hip_mobility",
            youtubeVideoId = null,
            illustrativeImageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Yoga_Warrior_I.jpg?width=800",
            illustrativeAttribution = "Imagen ilustrativa temática · Wikimedia Commons",
            videoUrl = "https://www.youtube.com/@gaiam/search?query=hip+mobility+stretch",
            channelUrl = VideoChannel.GAIAM.channelUrl,
            estimatedDuration = "Búsqueda temática · ~12–15 min"
        ),
        EducationalVideo(
            id = "gaiam_flexibility",
            title = "Rutina de flexibilidad y estiramiento restaurativo nocturno",
            channel = VideoChannel.GAIAM,
            category = VideoCategory.FLEXIBILITY,
            focusSummary = "Secuencia tranquila de elongación muscular pensada para el cierre del día.",
            viewsNote = "Visualizaciones e ID verificables en YouTube",
            localAssetBasePath = "images/videos/video_gaiam_flexibility",
            youtubeVideoId = null,
            illustrativeImageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Pilates-hamstring-stretch.jpg?width=800",
            illustrativeAttribution = "Imagen ilustrativa temática · Wikimedia Commons",
            videoUrl = "https://www.youtube.com/@gaiam/search?query=flexibility+stretch",
            channelUrl = VideoChannel.GAIAM.channelUrl,
            estimatedDuration = "Búsqueda temática · ~10–15 min"
        )
    )
}
