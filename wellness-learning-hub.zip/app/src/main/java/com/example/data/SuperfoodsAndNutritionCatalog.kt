package com.example.data

object SuperfoodsAndNutritionCatalog {
    val superfoods: List<SuperfoodItem> = listOf(
        SuperfoodItem(
            id = "sf_reishi",
            name = "Reishi (Lingzhi)",
            scientificName = "Ganoderma lucidum",
            category = SuperfoodCategory.MUSHROOMS,
            localAssetBasePath = "images/ingredientes/ingrediente_reishi",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Ganoderma_lucidum_01.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Ganoderma lucidum",
            origin = "Hongo tradicional asiático utilizado históricamente en infusiones herbales",
            bioactiveCompounds = listOf("Triterpenos (ácidos ganodéricos)", "Beta-glucanos", "Peptidoglucanos"),
            practicalUses = "Debido a su textura leñosa y sabor amargo, se utiliza en decocciones, tés o extractos duales en polvo por las tardes.",
            evidenceLevel = "Uso tradicional + estudios moderados",
            scientificSummary = "La investigación analiza su papel inmunomodulador sobre células inmunitarias y percepción de fatiga o descanso; no debe utilizarse como sustituto de tratamientos oncológicos o médicos.",
            precautions = "Puede interactuar con anticoagulantes, inmunosupresores y fármacos para la presión arterial. Se han reportado casos aislados de malestar digestivo con extractos concentrados."
        ),
        SuperfoodItem(
            id = "sf_lions_mane",
            name = "Melena de León",
            scientificName = "Hericium erinaceus",
            category = SuperfoodCategory.MUSHROOMS,
            localAssetBasePath = "images/ingredientes/ingrediente_melena_de_leon",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Hericium_erinaceus_wild.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Hericium erinaceus",
            origin = "Hongo culinario y tradicional originario de bosques templados de Asia, Europa y Norteamérica",
            bioactiveCompounds = listOf("Hericenonas", "Erinacinas", "Beta-glucanos", "Polisacáridos"),
            practicalUses = "Se consume cocinado en platillos salteados (textura similar al marisco) o en extractos estandarizados de cuerpo fructífero añadidos a café o infusiones.",
            evidenceLevel = "Evidencia preliminar en humanos",
            scientificSummary = "Estudios celulares y ensayos clínicos pequeños en adultos han explorado su posible apoyo al factor de crecimiento nervioso (NGF), bienestar cognitivo leve y confort digestivo, aunque se requieren estudios más amplios.",
            precautions = "Evitar en personas con alergia conocida a hongos. Consultar al médico en embarazo, lactancia o uso concomitante de anticoagulantes."
        ),
        SuperfoodItem(
            id = "sf_cordyceps",
            name = "Cordyceps militaris",
            scientificName = "Cordyceps militaris",
            category = SuperfoodCategory.MUSHROOMS,
            localAssetBasePath = "images/ingredientes/ingrediente_cordyceps",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Puppen-Kernkeule_Cordyceps_militaris.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Cordyceps militaris",
            origin = "Hongo cultivado actualmente de forma sostenible en sustratos vegetales para uso alimentario",
            bioactiveCompounds = listOf("Cordicepina", "Adenosina", "Polisacáridos"),
            practicalUses = "Polvo o extracto añadido a licuados matutinos o bebidas previas a caminatas y entrenamiento moderado.",
            evidenceLevel = "Evidencia exploratoria en tolerancia al esfuerzo",
            scientificSummary = "Ensayos piloto han evaluado su relación con el consumo máximo de oxígeno (VO2 máx.) y la fatiga percibida en adultos sanos; los resultados aún son heterogéneos.",
            precautions = "Precaución en trastornos autoinmunes o toma de anticoagulantes. Suspender antes de cirugías programadas."
        ),
        SuperfoodItem(
            id = "sf_ginger",
            name = "Jengibre fresco",
            scientificName = "Zingiber officinale",
            category = SuperfoodCategory.ROOTS_SPICES,
            localAssetBasePath = "images/ingredientes/ingrediente_jengibre",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Zingiber_officinale_001.JPG?width=800",
            imageAttribution = "Wikimedia Commons · Zingiber officinale",
            origin = "Rizoma aromático cultivado en regiones cálidas y ampliamente disponible en mercados de México",
            bioactiveCompounds = listOf("Gingeroles", "Shogaoles", "Zingibereno"),
            practicalUses = "Rallado en infusiones con limón, sopas, salteados de vegetales, licuados verdes o aguas frescas sin azúcar.",
            evidenceLevel = "Evidencia sólida en alivio de náuseas leves",
            scientificSummary = "Respaldado por múltiples ensayos clínicos para reducir náuseas leves y apoyar la motilidad gástrica; también se investiga su papel complementario frente a inflamación leve post-ejercicio.",
            precautions = "Moderar su consumo concentrado en caso de reflujo intenso o toma de medicamentos anticoagulantes."
        ),
        SuperfoodItem(
            id = "sf_ginseng",
            name = "Ginseng asiático",
            scientificName = "Panax ginseng",
            category = SuperfoodCategory.ROOTS_SPICES,
            localAssetBasePath = "images/ingredientes/ingrediente_ginseng",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Panax_ginseng_in_Kitchen.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Panax ginseng",
            origin = "Raíz carnosa tradicionalmente cultivada en Asia Oriental (Corea, noreste de China)",
            bioactiveCompounds = listOf("Ginsenósidos (Rg1, Rb1)", "Polisacáridos", "Péptidos"),
            practicalUses = "Se prepara en infusión suave de rodajas de raíz seca, caldos tradicionales o extractos estandarizados por periodos acotados.",
            evidenceLevel = "Evidencia moderada en fatiga leve",
            scientificSummary = "Estudios clínicos sugieren un efecto modesto sobre la sensación subjetiva de fatiga y vitalidad en adultos, aunque los resultados varían según la estandarización de ginsenósidos.",
            precautions = "Puede provocar insomnio o nerviosismo en dosis altas e interactuar con anticoagulantes (warfarina), hipoglucemiantes e inhibidores de la MAO; evitar en embarazo o hipertensión no controlada."
        ),
        SuperfoodItem(
            id = "sf_ashwagandha",
            name = "Ashwagandha",
            scientificName = "Withania somnifera",
            category = SuperfoodCategory.ROOTS_SPICES,
            localAssetBasePath = "images/ingredientes/ingrediente_ashwagandha",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Withania_somnifera_fruit.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Withania somnifera",
            origin = "Raíz adaptógena tradicional de la India, Oriente Medio y zonas áridas",
            bioactiveCompounds = listOf("Withanólidos", "Alcaloides", "Saponinas"),
            practicalUses = "Generalmente empleada en extractos de raíz estandarizados o polvo mezclado con bebidas tibias bajo orientación profesional.",
            evidenceLevel = "Evidencia clínica moderada en estrés percibido",
            scientificSummary = "Ensayos controlados recientes han mostrado reducciones moderadas en escalas de estrés percibido, cortisol matutino y calidad subjetiva del sueño en periodos de 6 a 8 semanas.",
            precautions = "Evitar en embarazo, hipertiroidismo sin control médico, enfermedades autoinmunes o uso de sedantes e inmunosupresores."
        ),
        SuperfoodItem(
            id = "sf_turmeric",
            name = "Cúrcuma con Pimienta Negra",
            scientificName = "Curcuma longa + Piper nigrum",
            category = SuperfoodCategory.ROOTS_SPICES,
            localAssetBasePath = "images/ingredientes/ingrediente_curcuma",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Curcuma_longa_roots.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Curcuma longa",
            origin = "Rizoma tropical de amplio uso culinario y herbolario tradicional",
            bioactiveCompounds = listOf("Curcuminoides (curcumina)", "Turmeronas", "Piperina (en pimienta negra)"),
            practicalUses = "En guisos, arroz, cremas de verduras, aderezos o 'leche dorada' acompañada de una pizca de pimienta negra y grasa saludable (aceite de oliva o coco) para mejorar su absorción.",
            evidenceLevel = "Evidencia clínica moderada en confort articular",
            scientificSummary = "Revisiones sistemáticas sugieren que los extractos estandarizados de curcumina pueden ayudar a modular marcadores inflamatorios y molestias articulares leves, con biodisponibilidad baja en forma cruda sin piperina.",
            precautions = "Dosis altas en suplemento pueden causar acidez o interactuar con anticoagulantes, antiagregantes y cálculos biliares."
        ),
        SuperfoodItem(
            id = "sf_chia",
            name = "Semilla de Chía",
            scientificName = "Salvia hispanica",
            category = SuperfoodCategory.SEEDS_ALGAE,
            localAssetBasePath = "images/ingredientes/ingrediente_chia",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Salvia_hispanica_27990281.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Salvia hispanica",
            origin = "Semilla nativa de Mesoamérica (México y Guatemala), pilar histórico de la alimentación regional",
            bioactiveCompounds = listOf("Ácido alfa-linolénico (Omega-3 vegetal)", "Fibra soluble mucilaginosa", "Calcio", "Polifenoles"),
            practicalUses = "Hidratada al menos 15 minutos en agua fresca de limón, avena nocturna, yogur natural o pudín con fruta de temporada.",
            evidenceLevel = "Evidencia nutricional sólida",
            scientificSummary = "Su aporte de fibra soluble favorece la saciedad, el tránsito intestinal y la estabilidad glucémica posprandial cuando forma parte de una dieta balanceada.",
            precautions = "Consumir siempre previamente hidratada y acompañada de suficiente líquido para evitar molestias esofágicas o digestivas."
        ),
        SuperfoodItem(
            id = "sf_spirulina",
            name = "Espirulina",
            scientificName = "Arthrospira platensis",
            category = SuperfoodCategory.SEEDS_ALGAE,
            localAssetBasePath = "images/ingredientes/ingrediente_espirulina",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Spirulina.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Spirulina",
            origin = "Cianobacteria microscópica tradicionalmente recolectada en lagos alcalinos (incluido el Valle de México)",
            bioactiveCompounds = listOf("Ficocianina", "Proteína completa (~60% en peso seco)", "Hierro", "Clorofila"),
            practicalUses = "Media a una cucharadita en licuados de piña, pepino o naranja, o en aderezos; elegir siempre marcas con análisis de pureza libre de microcistinas y metales pesados.",
            evidenceLevel = "Evidencia nutricional + estudios metabólicos iniciales",
            scientificSummary = "Aporta proteína vegetal y pigmentos antioxidantes como la ficocianina; estudios pequeños evalúan su apoyo en perfil lipídico y recuperación deportiva.",
            precautions = "No consumir en fenilcetonuria, trastornos autoinmunes activos o productos sin certificación de calidad."
        ),
        SuperfoodItem(
            id = "sf_matcha",
            name = "Té Verde Matcha",
            scientificName = "Camellia sinensis",
            category = SuperfoodCategory.SEEDS_ALGAE,
            localAssetBasePath = "images/ingredientes/ingrediente_matcha",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Matcha_layout_with_leaf,_tea,_and_powder.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Matcha",
            origin = "Hoja entera de té verde cultivada a la sombra y molida a la piedra",
            bioactiveCompounds = listOf("Catequinas (EGCG)", "L-teanina", "Cafeína natural", "Clorofila"),
            practicalUses = "Batido en agua tibia (no hirviendo, ~75–80 °C) solo o con bebida vegetal sin azúcares añadidos, preferentemente por la mañana.",
            evidenceLevel = "Evidencia sólida en atención y antioxidantes dietéticos",
            scientificSummary = "La combinación natural de L-teanina y cafeína favorece un estado de alerta sereno, mientras que el EGCG aporta actividad antioxidante dietética bien estudiada.",
            precautions = "Contiene cafeína: moderar en sensibilidad a estimulantes, hipertensión no controlada, embarazo o deficiencia de hierro (tomar lejos de comidas principales)."
        )
    )

    val nutritionTopics: List<NutritionTopic> = listOf(
        NutritionTopic(
            id = "nut_protein",
            title = "Proteínas funcionales para músculo y recuperación",
            tag = "Proteínas",
            localAssetBasePath = "images/nutricion/nutricion_proteinas",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Various_legumes.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Leguminosas variadas",
            summary = "Distribuir proteína de buena calidad a lo largo del día ayuda a preservar masa muscular, especialmente en adultos mayores y personas activas.",
            keyPoints = listOf(
                "Incluye una fuente proteica en desayuno, comida y cena (huevo, yogur natural, pescado, pollo, tofu, lentejas o frijoles).",
                "Complementa cereales integrales (maíz o arroz) con leguminosas o semillas (pepita de calabaza o ajonjolí) para perfil completo de aminoácidos.",
                "La síntesis proteica responde mejor cuando se combina con movimiento y ejercicios de fuerza."
            ),
            practicalMexicanContext = "Un desayuno sencillo con huevos a la mexicana y frijoles de la olla evita picos tempranos de hambre por exceso de pan dulce.",
            commonMythClarified = "Mito: 'Comer proteína daña los riñones sanos'. Realidad: En personas sin enfermedad renal previa, una ingesta moderada y bien distribuida es segura."
        ),
        NutritionTopic(
            id = "nut_vitamins",
            title = "Vitaminas esenciales de frutas y vegetales frescos",
            tag = "Vitaminas",
            localAssetBasePath = "images/nutricion/nutricion_vitaminas",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Citrus_fruits.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Frutas cítricas",
            summary = "Las vitaminas hidrosolubles (como C y complejo B) y liposolubles (A, D, E, K) participan en el metabolismo energético, visión, inmunidad y reparación tisular.",
            keyPoints = listOf(
                "Prioriza frutas enteras de temporada (guayaba, naranja, limón, papaya, mango) ricas en vitamina C y provitamina A.",
                "Cocina al vapor por tiempos breves para conservar mejor las vitaminas sensibles al calor.",
                "Acompaña verduras ricas en vitaminas A, E y K con una pequeña porción de grasa saludable (aguacate o aceite de oliva)."
            ),
            practicalMexicanContext = "En México, la guayaba, el pimiento, el jitomate y los cítricos aportan vitamina C accesible todo el año sin requerir megadosis en pastillas.",
            commonMythClarified = "Mito: 'Más vitamina en suplemento siempre significa más defensas'. Realidad: El exceso de ciertas vitaminas liposolubles puede acumularse; la base ideal es el alimento fresco."
        ),
        NutritionTopic(
            id = "nut_minerals",
            title = "Minerales clave e hidratación cotidiana",
            tag = "Minerales",
            localAssetBasePath = "images/nutricion/nutricion_minerales",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Spinach_leaves.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Hojas de espinaca",
            summary = "Minerales como hierro, magnesio, potasio, calcio y zinc sostienen la contracción muscular, conducción nerviosa, oxigenación e hidratación celular.",
            keyPoints = listOf(
                "Incluye verduras de hoja verde (espinaca, quelites, acelga), leguminosas y semillas ricas en magnesio y hierro vegetal.",
                "Combina fuentes de hierro vegetal con vitamina C (limón o jitomate) para favorecer su absorción.",
                "Mantén el agua simple como bebida principal y modera el sodio proveniente de botanas o embutidos."
            ),
            practicalMexicanContext = "El maíz nixtamalizado de las tortillas tradicionales aporta calcio biodisponible, mientras que las espinacas, nopales y frijoles aportan magnesio y potasio.",
            commonMythClarified = "Mito: 'Las bebidas deportivas comerciales son necesarias todos los días'. Realidad: Para actividad ligera cotidiana basta agua simple y comida real."
        ),
        NutritionTopic(
            id = "nut_antioxidants",
            title = "Antioxidantes y fitoquímicos naturales",
            tag = "Antioxidantes",
            localAssetBasePath = "images/nutricion/nutricion_antioxidantes",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Blueberries.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Moras azules (Blueberries)",
            summary = "Los pigmentos naturales de frutas, bayas, cacao, especias y tés ayudan a equilibrar el estrés oxidativo cotidiano dentro de una dieta variada.",
            keyPoints = listOf(
                "Busca colores intensos en el plato: morado (zarzamora, col morada, maíz azul), rojo (jitomate, fresa), verde (brócoli, té verde) y amarillo (cúrcuma).",
                "Prefiere la fruta entera con cáscara comestible en lugar de jugos filtrados.",
                "Combina especias culinarias como orégano, canela, clavo, cúrcuma y jengibre."
            ),
            practicalMexicanContext = "El maíz azul, los chiles secos y frescos, el cacao puro sin exceso de azúcar, la jamaica y las zarzamoras locales son fuentes destacadas de polifenoles.",
            commonMythClarified = "Mito: 'Un solo jugo detox antioxidante compensa malos hábitos'. Realidad: La protección celular depende del patrón alimentario y sueño constantes."
        ),
        NutritionTopic(
            id = "nut_fiber",
            title = "Fibra prebiótica y salud de la microbiota",
            tag = "Fibra",
            localAssetBasePath = "images/nutricion/nutricion_fibra",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Oatmeal.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Avena integral",
            summary = "La fibra dietética alimenta bacterias benéficas del intestino que producen ácidos grasos de cadena corta esenciales para el bienestar digestivo y metabólico.",
            keyPoints = listOf(
                "Incluye fibra soluble (avena, manzana, chía, frijoles) e insoluble (salvado, verduras crudas, semillas).",
                "Aumenta el consumo de fibra gradualmente para evitar distensión abdominal.",
                "Acompaña siempre un mayor aporte de fibra con agua simple suficiente."
            ),
            practicalMexicanContext = "El nopal, la tuna, el aguacate, la avena tradicional y los frijoles de la olla aportan fibra prebiótica económica todo el año.",
            commonMythClarified = "Mito: 'Solo los suplementos en polvo mejoran la digestión'. Realidad: La diversidad de plantas reales en la dieta nutre una microbiota mucho más resiliente."
        ),
        NutritionTopic(
            id = "nut_carbs",
            title = "Carbohidratos complejos y energía sostenida",
            tag = "Carbohidratos",
            localAssetBasePath = "images/nutricion/nutricion_carbohidratos",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Sweet_potatoes.JPG?width=800",
            imageAttribution = "Wikimedia Commons · Camote / batata natural",
            summary = "Los carbohidratos mínimamente procesados provenientes de tubérculos, granos enteros y leguminosas liberan glucosa de forma gradual y aportan vitaminas, minerales y fibra.",
            keyPoints = listOf(
                "Prioriza fuentes integrales como tortilla de maíz nixtamalizado, camote, papa con cáscara, avena, arroz integral y quinoa.",
                "Combina los carbohidratos con proteína y verdura en el mismo plato para modular la respuesta glucémica.",
                "Limita bebidas azucaradas, panadería refinada y jarabes concentrados de consumo diario."
            ),
            practicalMexicanContext = "El camote cocido, los elotes tiernos, el amaranto tostado sin azúcar excesiva y las tortillas de maíz tradicional brindan energía cotidiana accesible.",
            commonMythClarified = "Mito: 'Todos los carbohidratos engordan por igual'. Realidad: No es equivalente un refresco ultraprocesado que un camote, frijoles o maíz integral dentro de porciones equilibradas."
        ),
        NutritionTopic(
            id = "nut_natural_foods",
            title = "Alimentos naturales y el Plato del Bien Comer",
            tag = "Alimentos naturales",
            localAssetBasePath = "images/nutricion/nutricion_alimentos_naturales",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Healthy_food.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Alimentos frescos variados",
            summary = "Priorizar alimentos mínimamente procesados permite cubrir saciedad y micronutrientes sin exceso de azúcares añadidos, harinas refinadas ni sodio.",
            keyPoints = listOf(
                "Procura que la mitad del plato incluya verduras variadas y frescas de temporada.",
                "Combina cereales integrales con leguminosas o proteínas frescas preparadas al vapor, asadas o a la plancha.",
                "Planifica colaciones naturales como fruta de temporada, jícama, pepino o un puñado de nueces."
            ),
            practicalMexicanContext = "La dieta tradicional de milpa (maíz, frijol, calabaza, chile y quelites) es un ejemplo sobresaliente de alimentos naturales accesibles en mercados locales.",
            commonMythClarified = "Mito: 'Comer natural siempre es más caro'. Realidad: Comprar frutas, verduras y leguminosas de temporada en mercado local suele ser más económico que los ultraprocesados."
        ),
        NutritionTopic(
            id = "nut_fats",
            title = "Grasas saludables y equilibrio inflamatorio",
            tag = "Grasas saludables",
            localAssetBasePath = "images/nutricion/nutricion_grasas_saludables",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Avocado_open_side_by_side.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Aguacate fresco",
            summary = "Las grasas mono y poliinsaturadas protegen el sistema cardiovascular y favorecen la absorción de vitaminas A, D, E y K.",
            keyPoints = listOf(
                "Elige fuentes naturales: aguacate, aceite de oliva extra virgen, nueces, almendras, chía y pescados grasos (sardina, salmón).",
                "Evita grasas trans industriales presentes en panadería empaquetada y botanas fritas.",
                "Mide el aceite al cocinar en lugar de verterlo libremente."
            ),
            practicalMexicanContext = "El aguacate fresco, el cacahuate natural tostado sin sal añadida y la pepita de calabaza son aliados cotidianos y nutritivos.",
            commonMythClarified = "Mito: 'Eliminar por completo las grasas es lo más saludable'. Realidad: Las grasas esenciales son indispensables para hormonas, cerebro y membranas celulares."
        ),
        NutritionTopic(
            id = "nut_labels",
            title = "Lectura práctica de etiquetas y sellos (NOM-051)",
            tag = "Etiquetado",
            localAssetBasePath = "images/nutricion/nutricion_etiquetado",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Whole_foods_produce_dept.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Sección de productos frescos",
            summary = "Revisar la lista de ingredientes y el etiquetado frontal permite tomar decisiones informadas al hacer el súper.",
            keyPoints = listOf(
                "Los ingredientes se enlistan de mayor a menor peso: si azúcar, jarabe o harina refinada aparecen al inicio, predominan en el producto.",
                "Observa los octágonos negros de advertencia (Exceso Calorías, Azúcares, Sodio, Grasas Saturadas y Trans) como guía rápida.",
                "Prefiere alimentos con listas cortas de ingredientes reconocibles en una cocina doméstica."
            ),
            practicalMexicanContext = "En México, la Norma Oficial Mexicana NOM-051 facilita identificar en segundos bebidas y botanas con exceso de sodio o azúcares añadidos.",
            commonMythClarified = "Mito: 'Si dice light o natural al frente no tiene azúcares añadidos'. Realidad: Muchos productos reducidos en grasa compensan el sabor agregando jarabes o almidones."
        )
    )
}
