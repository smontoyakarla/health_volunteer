package com.example.data

object MovementCommunitySourcesCatalog {
    val movementRoutines: List<MovementRoutine> = listOf(
        MovementRoutine(
            id = "mov_yoga",
            title = "Yoga suave y respiración consciente",
            bodyArea = "Yoga",
            durationLabel = "10 min",
            level = "Principiante · Tapete",
            localAssetBasePath = "images/movimiento/movimiento_yoga",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Yoga_Stretch.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Yoga Stretch",
            objective = "Integrar respiración diafragmática lenta con posturas accesibles para liberar rigidez general y calmar el sistema nervioso.",
            steps = listOf(
                "Siéntate con piernas cruzadas o sobre una silla firme, alarga la columna e inhala por la nariz durante 4 segundos.",
                "Exhala lento en 6 segundos relajando mandíbula y hombros lejos de las orejas durante 5 ciclos.",
                "Pasa a postura de gato-vaca en cuatro puntos realizando 8 transiciones lentas sincronizadas con tu respiración.",
                "Finaliza descansando en postura del niño con rodillas separadas y frente apoyada sobre el tapete o un cojín."
            ),
            safetyTip = "No fuerces rodillas ni muñecas; usa una toalla doblada bajo las rodillas o realiza las inclinaciones sentado.",
            relatedVideoCategory = VideoCategory.YOGA
        ),
        MovementRoutine(
            id = "mov_foam_roller",
            title = "Recuperación corporal con rodillos de masaje",
            bodyArea = "Rodillos de masaje",
            durationLabel = "8 min",
            level = "Recuperación suave",
            localAssetBasePath = "images/movimiento/movimiento_rodillos_espuma",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Foam_rolling.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Foam rolling",
            objective = "Liberar tensión muscular superficial en espalda dorsal, pantorrillas y muslos usando un rodillo de espuma (foam roller) de densidad media.",
            steps = listOf(
                "Coloca el rodillo horizontalmente bajo la parte media-alta de la espalda (zona de omóplatos), sostén la cabeza con las manos y deslízate lento 30–45 segundos.",
                "Siéntate con el rodillo bajo las pantorrillas y rueda suavemente desde el tobillo hasta abajo de la rodilla sin presionar el hueco poplíteo.",
                "Trabaja la parte frontal o lateral del muslo con presión tolerable, manteniendo respiración continua sin contener el aire."
            ),
            safetyTip = "No pases el rodillo directamente sobre la zona lumbar baja, articulaciones óseas ni sobre várices, hematomas o heridas.",
            relatedVideoCategory = VideoCategory.FOAM_ROLLER
        ),
        MovementRoutine(
            id = "mov_stretching",
            title = "Estiramientos para cuello, hombros y espalda",
            bodyArea = "Estiramientos",
            durationLabel = "6 min",
            level = "Principiante · En silla o de pie",
            localAssetBasePath = "images/movimiento/movimiento_estiramientos",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Stretching_exercise.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Stretching exercise",
            objective = "Disminuir la sobrecarga cervical y escapular acumulada tras horas frente a escritorio o teléfono celular.",
            steps = listOf(
                "Siéntate con la espalda erguida y realiza 6 círculos lentos con ambos hombros hacia atrás.",
                "Inclina suavemente la oreja derecha hacia el hombro derecho sin elevar el hombro izquierdo; sostén 20 segundos por lado.",
                "Lleva la barbilla ligeramente hacia atrás ('doble mentón suave') durante 5 segundos y repite 5 veces.",
                "Entrelaza las manos por delante del pecho y empuja suave hacia el frente redondeando la parte alta de la espalda 15 segundos."
            ),
            safetyTip = "Evita giros bruscos de cuello hacia atrás y detén el estiramiento si aparece mareo, hormigueo en brazos o dolor agudo.",
            relatedVideoCategory = VideoCategory.STRETCHING
        ),
        MovementRoutine(
            id = "mov_mobility",
            title = "Movilidad articular para rodillas y cadera",
            bodyArea = "Movilidad",
            durationLabel = "8 min",
            level = "Bajo impacto",
            localAssetBasePath = "images/movimiento/movimiento_movilidad",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Prone_Knee_Flexion.JPG?width=800",
            imageAttribution = "Wikimedia Commons · Prone Knee Flexion",
            objective = "Lubricar articulaciones de rodilla, tobillo y cadera con rangos controlados antes de caminar o iniciar actividades diarias.",
            steps = listOf(
                "Sentado en silla firme, extiende una rodilla hasta alinear la pierna, sostén 3 segundos contrayendo suavemente el muslo y baja lento (10 repeticiones por lado).",
                "De pie sujetado de una silla, realiza 10 círculos suaves de tobillo en cada dirección y 10 elevaciones lentas de talones.",
                "Con apoyo estable, balancea suavemente una pierna adelante y atrás dentro de un rango cómodo para movilizar la cadera."
            ),
            safetyTip = "Evita bloquear bruscamente la rodilla al extenderla y suspende si notas inflamación o chasquidos dolorosos.",
            relatedVideoCategory = VideoCategory.MOBILITY
        ),
        MovementRoutine(
            id = "mov_flexibility",
            title = "Flexibilidad progresiva de piernas y cadena posterior",
            bodyArea = "Flexibilidad",
            durationLabel = "8 min",
            level = "Suave · Principiante",
            localAssetBasePath = "images/movimiento/movimiento_flexibilidad",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Flexibility.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Flexibility",
            objective = "Mejorar de forma gradual la elasticidad de isquiotibiales, pantorrillas y flexores de cadera sin rebotes.",
            steps = listOf(
                "Recostado boca arriba, pasa una toalla o banda larga bajo la planta del pie y eleva la pierna casi recta hasta sentir elongación suave detrás del muslo (25 segundos por lado).",
                "En posición de desplante suave con rodilla trasera apoyada en un cojín, adelanta ligeramente la pelvis para estirar el flexor de cadera.",
                "De pie frente a una pared, da un paso atrás con un pie manteniendo el talón apoyado para estirar la pantorrilla 20 segundos."
            ),
            safetyTip = "Mantén estiramientos estáticos suaves sin rebotes bruscos ni sensación de dolor punzante.",
            relatedVideoCategory = VideoCategory.FLEXIBILITY
        ),
        MovementRoutine(
            id = "mov_strength",
            title = "Ejercicios de fortalecimiento postural y zona media",
            bodyArea = "Fortalecimiento muscular",
            durationLabel = "10 min",
            level = "Progresivo · Sin equipo",
            localAssetBasePath = "images/movimiento/movimiento_fortalecimiento",
            imageUrl = "https://commons.wikimedia.org/wiki/Special:FilePath/Plank.jpg?width=800",
            imageAttribution = "Wikimedia Commons · Plank exercise",
            objective = "Fortalecer musculatura profunda de abdomen, glúteos y cintura escapular para proteger la columna en la vida cotidiana.",
            steps = listOf(
                "Recostado boca arriba con rodillas flexionadas, eleva la cadera formando un puente de glúteos, sostén 3 segundos y baja lento (12 repeticiones).",
                "Apoya antebrazos sobre una pared, mesa firme o tapete (según tu nivel) para mantener una plancha alineada durante 15–25 segundos sin hundir la cintura.",
                "Sentado o de pie, junta suavemente los omóplatos hacia atrás y abajo durante 5 segundos (10 repeticiones)."
            ),
            safetyTip = "Prioriza la alineación de espalda neutra sobre la duración; si la zona lumbar se arquea, apoya las rodillas o realiza la plancha inclinada en pared.",
            relatedVideoCategory = VideoCategory.STRENGTH
        )
    )

    val communitySummaryIntro =
        "Las jornadas comunitarias de bienestar nos permitieron llevar educación preventiva accesible a familias, jóvenes y adultos mayores, integrando pausas de movimiento, orientación alimentaria y alfabetización responsable sobre equipos de descanso y bienestar."

    val communityStations: List<CommunityStation> = listOf(
        CommunityStation(
            stepNumber = "01",
            title = "Estación de Bienvenida y Tamizaje Preventivo",
            description = "Registro cordial y cuestionario breve de seguridad previo antes de cualquier actividad física o demostración informativa de equipos.",
            safetyPractice = "Identificación obligatoria de marcapasos, embarazo, cirugías recientes o mareo para derivar a actividades 100% seguras."
        ),
        CommunityStation(
            stepNumber = "02",
            title = "Estación de Movimiento Guiado y Postura",
            description = "Talleres prácticos de 10 minutos sobre estiramientos en silla, cuidado de cuello, hombros y fortalecimiento suave de rodillas.",
            safetyPractice = "Adaptación de cada postura a personas con movilidad reducida y énfasis en no trabajar con dolor agudo."
        ),
        CommunityStation(
            stepNumber = "03",
            title = "Estación de Nutrición e Ingredientes de Milpa",
            description = "Charlas visuales sobre hidratación con agua simple, uso de chía, cúrcuma, jengibre y lectura de sellos NOM-051.",
            safetyPractice = "Enfoque realista al presupuesto familiar mexicano sin promover suplementos milagro ni dietas restrictivas."
        ),
        CommunityStation(
            stepNumber = "04",
            title = "Estación Informativa de Tecnologías de Bienestar",
            description = "Explicación transparente de cómo operan equipos como Hot House, Sun Ancon Chi Machine, E-Power y ERE, aclarando su alcance y limitaciones.",
            safetyPractice = "Comunicación ética: nunca diagnosticar, nunca prometer curaciones y siempre recomendar seguimiento médico cuando exista síntoma clínico."
        )
    )

    val communityLearnings: List<CommunityLearning> = listOf(
        CommunityLearning(
            title = "Educación antes que promesa comercial",
            detail = "Las personas valoran mucho más entender cómo funciona un equipo, qué dice la ciencia y cuáles son sus contraindicaciones que escuchar afirmaciones exageradas."
        ),
        CommunityLearning(
            title = "Accesibilidad digital y lenguaje claro",
            detail = "El uso de español de México cercano, tipografía legible y pasos breves facilita que adultos mayores y familias adopten pausas activas en casa."
        ),
        CommunityLearning(
            title = "Evolución como proyecto de Ingeniería en Informática",
            detail = "Esta aplicación está diseñada con arquitectura MVVM desacoplada, carga y caché de imágenes remotas con Coil, persistencia local segura con DataStore y trazabilidad de fuentes."
        )
    )

    val sources: List<ScientificSource> = listOf(
        ScientificSource(
            id = "src_who_pa",
            title = "Directrices sobre actividad física y hábitos sedentarios",
            organization = "Organización Mundial de la Salud (OMS)",
            category = SourceCategory.PUBLIC_HEALTH,
            description = "Recomendaciones globales basadas en evidencia sobre movimiento semanal, fuerza muscular y reducción del sedentarismo por grupos de edad.",
            url = "https://www.who.int/es/news-room/fact-sheets/detail/physical-activity"
        ),
        ScientificSource(
            id = "src_nccih",
            title = "Información basada en evidencia sobre salud integrativa, hongos y hierbas",
            organization = "NIH - National Center for Complementary and Integrative Health (NCCIH)",
            category = SourceCategory.SCIENTIFIC,
            description = "Fichas técnicas imparciales sobre cúrcuma, jengibre, ginseng, ashwagandha, té verde, yoga y terapias físicas complementarias.",
            url = "https://www.nccih.nih.gov/health/espanol"
        ),
        ScientificSource(
            id = "src_medlineplus",
            title = "Enciclopedia médica educativa sobre nutrición y fisioterapia",
            organization = "MedlinePlus en español (Biblioteca Nacional de Medicina de EE. UU.)",
            category = SourceCategory.PUBLIC_HEALTH,
            description = "Guías claras para pacientes sobre hidratación, fibra, dolor de espalda, rodillas y precauciones con dispositivos eléctricos.",
            url = "https://medlineplus.gov/spanish/"
        ),
        ScientificSource(
            id = "src_pubmed",
            title = "Base de datos de literatura biomédica (FIR, TENS y movimiento pasivo)",
            organization = "PubMed / NCBI",
            category = SourceCategory.SCIENTIFIC,
            description = "Buscador oficial de artículos revisados por pares sobre infrarrojo lejano, electroestimulación transcutánea e ingredientes bioactivos.",
            url = "https://pubmed.ncbi.nlm.nih.gov/"
        ),
        ScientificSource(
            id = "src_insp_mexico",
            title = "Guías Alimentarias Saludables y Sostenibles para la población mexicana",
            organization = "Instituto Nacional de Salud Pública (INSP) / Secretaría de Salud",
            category = SourceCategory.PUBLIC_HEALTH,
            description = "Marco nacional de referencia sobre alimentación saludable, sostenibilidad e hidratación con agua simple.",
            url = "https://www.gob.mx/salud"
        ),
        ScientificSource(
            id = "src_tone_tighten",
            title = "Canal educativo de fisioterapia y movilidad: Tone and Tighten",
            organization = "YouTube · @toneandtighten",
            category = SourceCategory.MOVEMENT,
            description = "Rutinas guiadas de estiramientos, fortalecimiento y cuidado de espalda, cuello y rodillas impartidas por fisioterapeuta.",
            url = "https://www.youtube.com/@toneandtighten"
        ),
        ScientificSource(
            id = "src_gaiam",
            title = "Canal de yoga, flexibilidad y recuperación corporal: GAIAM",
            organization = "YouTube · @gaiam",
            category = SourceCategory.MOVEMENT,
            description = "Clases y demostraciones prácticas de yoga para principiantes, movilidad y uso de rodillos de masaje.",
            url = "https://www.youtube.com/@gaiam"
        ),
        ScientificSource(
            id = "src_hte_global",
            title = "Documentación del fabricante HTE International (SOQI / Hot House / E-Power / ERE / Chi Machine)",
            organization = "HTE International (Hsin Ten Enterprise)",
            category = SourceCategory.MANUFACTURERS,
            description = "Sitio oficial del fabricante con descripciones comerciales, catálogos y advertencias de uso de sus líneas de equipos.",
            url = "https://www.hteglobal.com/"
        ),
        ScientificSource(
            id = "src_soqi_universe",
            title = "Catálogo informativo SOQI Universe",
            organization = "SOQI Universe",
            category = SourceCategory.MANUFACTURERS,
            description = "Fuente comercial de referencia para equipos Hot House, E-Power, Electro Reflex Energizer y Chi Machine.",
            url = "https://www.soqiuniverse.com/"
        )
    )
}
