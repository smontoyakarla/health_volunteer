package com.example.data

import android.content.Context
import java.util.concurrent.ConcurrentHashMap

data class ResolvedMedia(
    val model: String?,
    val provenanceLabel: String,
    val isLocalAsset: Boolean
)

object LocalMediaResolver {
    private val supportedExtensions = listOf("webp", "jpg", "jpeg", "png")
    private val directoryCache = ConcurrentHashMap<String, Set<String>>()

    fun clearCacheForTesting() {
        directoryCache.clear()
    }

    fun resolveLocalAssetUri(context: Context, localAssetBasePath: String?): String? {
        val normalized = localAssetBasePath
            ?.trim()
            ?.removePrefix("/")
            ?.takeIf { it.isNotEmpty() }
            ?: return null

        val lastSlash = normalized.lastIndexOf('/')
        if (lastSlash <= 0) return null

        val directory = normalized.substring(0, lastSlash)
        val baseName = normalized.substring(lastSlash + 1)
        val files = directoryCache.getOrPut(directory) {
            runCatching { context.assets.list(directory)?.toSet() ?: emptySet() }
                .getOrDefault(emptySet())
        }
        if (files.isEmpty()) return null

        val matchedFile = supportedExtensions.firstNotNullOfOrNull { ext ->
            val candidate = "$baseName.$ext"
            files.firstOrNull { it.equals(candidate, ignoreCase = true) }
        } ?: return null

        return "file:///android_asset/$directory/$matchedFile"
    }

    fun resolveMedia(
        context: Context,
        localAssetBasePath: String?,
        remoteUrl: String?,
        remoteSourceLabel: String?,
        localSourceLabel: String = "Archivo local integrado",
        pendingLabel: String = "Espacio reservado · Archivo local pendiente"
    ): ResolvedMedia {
        val localUri = resolveLocalAssetUri(context, localAssetBasePath)
        if (localUri != null) {
            return ResolvedMedia(
                model = localUri,
                provenanceLabel = localSourceLabel,
                isLocalAsset = true
            )
        }

        val cleanRemote = remoteUrl?.takeIf { it.isNotBlank() }
        if (cleanRemote != null) {
            return ResolvedMedia(
                model = cleanRemote,
                provenanceLabel = remoteSourceLabel ?: "Fuente externa verificada",
                isLocalAsset = false
            )
        }

        return ResolvedMedia(
            model = null,
            provenanceLabel = pendingLabel,
            isLocalAsset = false
        )
    }
}
