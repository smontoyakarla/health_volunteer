package com.example.data

class WellnessRepository {
    fun getVideos(): List<EducationalVideo> = VideosCatalog.videos

    fun getDevices(): List<WellnessDevice> = TechnologiesCatalog.devices

    fun getDeviceById(id: String): WellnessDevice? =
        TechnologiesCatalog.devices.firstOrNull { it.id == id }

    fun getSuperfoods(): List<SuperfoodItem> = SuperfoodsAndNutritionCatalog.superfoods

    fun getNutritionTopics(): List<NutritionTopic> = SuperfoodsAndNutritionCatalog.nutritionTopics

    fun getMovementRoutines(): List<MovementRoutine> = MovementCommunitySourcesCatalog.movementRoutines

    fun getCommunityIntro(): String = MovementCommunitySourcesCatalog.communitySummaryIntro

    fun getCommunityStations(): List<CommunityStation> = MovementCommunitySourcesCatalog.communityStations

    fun getCommunityLearnings(): List<CommunityLearning> = MovementCommunitySourcesCatalog.communityLearnings

    fun getSources(): List<ScientificSource> = MovementCommunitySourcesCatalog.sources

    fun getAllBookmarkableEntries(): Map<String, BookmarkEntry> {
        val map = mutableMapOf<String, BookmarkEntry>()
        getVideos().forEach {
            map[it.id] = BookmarkEntry(
                id = it.id,
                type = "Video educativo",
                title = it.title,
                subtitle = "${it.channel.displayName} · ${it.category.label}",
                targetRoute = WellnessSectionRoute.VIDEOS.route
            )
        }
        getDevices().forEach {
            map[it.id] = BookmarkEntry(
                id = it.id,
                type = "Tecnología HTE",
                title = it.name,
                subtitle = it.subtitle,
                targetRoute = "device_detail/${it.id}"
            )
        }
        getSuperfoods().forEach {
            map[it.id] = BookmarkEntry(
                id = it.id,
                type = "Superalimento",
                title = it.name,
                subtitle = "${it.category.label} · ${it.scientificName}",
                targetRoute = WellnessSectionRoute.SUPERFOODS.route
            )
        }
        getNutritionTopics().forEach {
            map[it.id] = BookmarkEntry(
                id = it.id,
                type = "Guía nutricional",
                title = it.title,
                subtitle = it.tag,
                targetRoute = WellnessSectionRoute.NUTRITION.route
            )
        }
        getMovementRoutines().forEach {
            map[it.id] = BookmarkEntry(
                id = it.id,
                type = "Rutina de movimiento",
                title = it.title,
                subtitle = "${it.bodyArea} · ${it.durationLabel}",
                targetRoute = WellnessSectionRoute.MOVEMENT.route
            )
        }
        return map
    }
}
