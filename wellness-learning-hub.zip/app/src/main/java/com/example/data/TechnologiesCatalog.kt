package com.example.data

object TechnologiesCatalog {
    private const val HTE_BASE_URL = "https://www.hteglobal.com/"
    private const val SOQI_UNIVERSE_URL = "https://www.soqiuniverse.com/"

    val devices: List<WellnessDevice> = listOf(
        WellnessDevice(
            id = "hot_house",
            name = "Hot House",
            subtitle = "Domo de calor por infrarrojo lejano (FIR)",
            localAssetBasePath = "images/equipos/equipo_hot_house",
            officialImageUrl = null,
            officialVisualNote = "Fotografía del equipo incorporada localmente a partir de las imágenes proporcionadas (referencia de catálogo SOQI Universe / HTE International).",
            officialProductUrl = HTE_BASE_URL,
            secondarySourceUrl = SOQI_UNIVERSE_URL,
            generalDescription = "Equipo curvo en forma de túnel o domo diseñado para emitir energía térmica de infrarrojo lejano (Far Infrared / FIR) sobre zonas específicas del cuerpo mientras la persona permanece recostada en reposo.",
            manufacturer = "HTE International (Hsin Ten Enterprise / ecosistema SOQI)",
            manufacturerUrl = HTE_BASE_URL,
            technologyUsed = "Emisión de radiación térmica de infrarrojo lejano (longitud de onda larga, banda no ionizante) mediante superficie cerámica curva.",
            howItWorksSimple = "A diferencia de una lámpara que calienta principalmente el aire alrededor, el infrarrojo lejano transfiere calor suave de manera radiante hacia las capas superficiales de la piel y tejido subcutáneo, generando una sensación de tibieza uniforme similar al calor solar matutino sin radiación UV.",
            verifiedSpecs = listOf(
                TechSpecRow("Formato físico", "Domo semicircular portátil con elevadores ajustables"),
                TechSpecRow("Tipo de energía", "Infrarrojo lejano (FIR) no ionizante"),
                TechSpecRow("Rango térmico habitual", "Calor suave localizado (consultar etiqueta del modelo regional)"),
                TechSpecRow("Integración", "Compatible como componente del sistema de descanso SOQI Bed")
            ),
            manufacturerUsage = "El fabricante lo describe como un apoyo de relajación térmica para sesiones de descanso en casa o cabinas de bienestar, orientado a promover confort muscular, sudoración ligera y sensación de relajación.",
            relatedResearch = "La literatura biomédica sobre terapia con infrarrojo lejano (FIR) ha estudiado efectos térmicos y no térmicos sobre la microcirculación periférica, la relajación de tejidos blandos y el confort en dolor musculoesquelético crónico leve en estudios piloto y revisiones clínicas de calor localizado.",
            evidenceAndLimitations = "La evidencia disponible sugiere beneficios moderados como terapia de calor superficial para relajación y alivio temporal de rigidez muscular. Sin embargo, los estudios específicos sobre la marca son limitados, con muestras pequeñas, y no respaldan afirmaciones de curación de enfermedades sistémicas o metabólicas.",
            precautionsAndContraindications = listOf(
                "Evitar su uso durante el embarazo sobre la zona abdominal o lumbar.",
                "No utilizar en personas con neuropatía o pérdida de sensibilidad al calor (riesgo de quemadura).",
                "Contraindicado en fiebre alta, procesos inflamatorios agudos o infecciones activas.",
                "Consultar previamente con un médico si existen implantes metálicos, gel de silicona o antecedentes oncológicos activos.",
                "Mantener hidratación adecuada y suspender ante mareo o incomodidad térmica."
            ),
            sources = listOf(
                DeviceSourceLink("Portal oficial HTE International", "HTE International", HTE_BASE_URL),
                DeviceSourceLink("Catálogo informativo SOQI Universe", "SOQI Universe", SOQI_UNIVERSE_URL),
                DeviceSourceLink("Información sobre calor infrarrojo y seguridad térmica", "NIH / PubMed", "https://pubmed.ncbi.nlm.nih.gov/")
            )
        ),
        WellnessDevice(
            id = "e_power",
            name = "E-Power",
            subtitle = "Equipo de potencial eléctrico negativo y alta frecuencia",
            localAssetBasePath = "images/equipos/equipo_e_power",
            officialImageUrl = null,
            officialVisualNote = "Fotografía del equipo incorporada localmente a partir de las imágenes proporcionadas (referencia de catálogo SOQI Universe / HTE International).",
            officialProductUrl = HTE_BASE_URL,
            secondarySourceUrl = SOQI_UNIVERSE_URL,
            generalDescription = "Dispositivo eléctrico de uso en reposo que conecta al usuario a un tapete o cinturón conductor aislado del suelo para aplicar un campo electrostático de potencial negativo y alta frecuencia de baja corriente.",
            manufacturer = "HTE International (Hsin Ten Enterprise)",
            manufacturerUrl = HTE_BASE_URL,
            technologyUsed = "Generación de potencial eléctrico negativo (EPN) combinado con señal de alta frecuencia y corriente mínima controlada.",
            howItWorksSimple = "El equipo utiliza el cuerpo humano aislado mediante un tapete especial como si fuera un pequeño condensador eléctrico superficial, buscando generar una sensación de descanso profundo. Requiere retirar objetos metálicos o electrónicos durante la sesión.",
            verifiedSpecs = listOf(
                TechSpecRow("Modalidad", "Potencial negativo y alta frecuencia en sesión pasiva"),
                TechSpecRow("Accesorios reportados", "Unidad principal, tapete aislante y banda/cinturón conductor"),
                TechSpecRow("Requisito operativo", "Retirar joyería, relojes y dispositivos electrónicos durante la sesión"),
                TechSpecRow("Recomendación de uso", "Tomar agua natural antes y después de la sesión según manual")
            ),
            manufacturerUsage = "El fabricante lo presenta como un equipo de bienestar energético para acompañar hábitos de descanso, higiene del sueño y sensación de vitalidad cotidiana, dentro de sesiones cronometradas de baja intensidad.",
            relatedResearch = "Existen publicaciones en fisiología básica que exploran la exposición a campos eléctricos de alto voltaje/potencial negativo sobre variables como variabilidad de la frecuencia cardiaca y estrés percibido, principalmente en estudios preliminares de Japón y Taiwán.",
            evidenceAndLimitations = "La evidencia clínica independiente en humanos sigue siendo limitada y heterogénea. No existen ensayos clínicos aleatorizados a gran escala que validen efectos terapéuticos específicos sobre enfermedades crónicas; su rol debe considerarse exclusivamente complementario y recreativo-educativo.",
            precautionsAndContraindications = listOf(
                "Contraindicación absoluta en personas con marcapasos, desfibriladores implantables u otros dispositivos electrónicos médicos.",
                "No usar durante el embarazo ni durante la menstruación según las advertencias del fabricante.",
                "Evitar en personas con trasplantes de órganos, implantes de silicona o insuficiencia renal grave.",
                "Contraindicado en fiebre alta, tumores activos, cardiopatías graves o dentro de la primera hora tras consumir alcohol.",
                "Retirar cualquier objeto metálico antes de iniciar."
            ),
            sources = listOf(
                DeviceSourceLink("Portal oficial HTE International", "HTE International", HTE_BASE_URL),
                DeviceSourceLink("Catálogo informativo SOQI Universe", "SOQI Universe", SOQI_UNIVERSE_URL),
                DeviceSourceLink("Búsqueda de literatura sobre terapia de potencial eléctrico", "PubMed / NCBI", "https://pubmed.ncbi.nlm.nih.gov/")
            )
        ),
        WellnessDevice(
            id = "electro_reflex_energizer",
            name = "Electro Reflex Energizer (ERE)",
            subtitle = "Electroestimulación de baja frecuencia para pies y zonas musculares",
            localAssetBasePath = "images/equipos/equipo_electro_reflex_energizer",
            officialImageUrl = null,
            officialVisualNote = "Fotografía del equipo incorporada localmente a partir de las imágenes proporcionadas (referencia de catálogo SOQI Universe / HTE International).",
            officialProductUrl = HTE_BASE_URL,
            secondarySourceUrl = SOQI_UNIVERSE_URL,
            generalDescription = "Plataforma para las plantas de los pies acompañada de electrodos adhesivos externos que emite impulsos eléctricos de baja frecuencia inspirados en principios de TENS/EMS y reflexología plantar.",
            manufacturer = "HTE International (Hsin Ten Enterprise)",
            manufacturerUrl = HTE_BASE_URL,
            technologyUsed = "Electroestimulación neuromuscular y nerviosa transcutánea de baja frecuencia (principios tipo TENS / EMS) con modos secuenciales.",
            howItWorksSimple = "Al colocar los pies descalzos sobre las placas o adherir los electrodos en hombros o espalda, se envían pulsos eléctricos suaves que producen un cosquilleo rítmico y microcontracciones musculares, ayudando a relajar pies cansados y tensión localizada.",
            verifiedSpecs = listOf(
                TechSpecRow("Aplicación principal", "Placas plantares para pies y parches/electrodos corporales"),
                TechSpecRow("Señal", "Impulsos eléctricos de baja frecuencia con intensidad regulable"),
                TechSpecRow("Modos", "Múltiples patrones de pulsación y temporizador"),
                TechSpecRow("Supervisión", "Requiere contacto con piel limpia, intacta y sin heridas")
            ),
            manufacturerUsage = "Promocionado por el fabricante para confort plantar tras largas jornadas de pie, relajación muscular en pantorrillas, piernas o espalda mediante sus electrodos auxiliares, y bienestar general.",
            relatedResearch = "La electroestimulación nerviosa transcutánea (TENS) y la estimulación muscular eléctrica (EMS) cuentan con amplia documentación clínica en fisioterapia para modulación temporal del dolor musculoesquelético leve y recuperación muscular localizada.",
            evidenceAndLimitations = "Si bien el principio general TENS/EMS está bien documentado en fisioterapia, los efectos dependen de parámetros calibrados y uso adecuado; las afirmaciones amplias de 'reflexología energética' sobre órganos internos carecen de respaldo clínico sólido.",
            precautionsAndContraindications = listOf(
                "Contraindicación absoluta con marcapasos, neuroestimuladores o implantes electrónicos.",
                "No aplicar sobre el cuello anterior (seno carotídeo), pecho/área cardiaca ni cabeza.",
                "Evitar durante el embarazo, en personas con antecedentes de epilepsia o arritmias.",
                "No usar si hay trombosis venosa profunda (TVP), flebitis, heridas abiertas o úlceras en los pies.",
                "Consultar al médico en personas con diabetes avanzada que presenten pérdida de sensibilidad plantar."
            ),
            sources = listOf(
                DeviceSourceLink("Portal oficial HTE International", "HTE International", HTE_BASE_URL),
                DeviceSourceLink("Catálogo informativo SOQI Universe", "SOQI Universe", SOQI_UNIVERSE_URL),
                DeviceSourceLink("Guía clínica general sobre TENS y seguridad eléctrica", "MedlinePlus (NIH)", "https://medlineplus.gov/spanish/")
            )
        ),
        WellnessDevice(
            id = "sun_ancon_chi_machine",
            name = "Sun Ancon Chi Machine",
            subtitle = "Oscilador aeróbico pasivo de movimiento lateral",
            localAssetBasePath = "images/equipos/equipo_sun_ancon_chi_machine",
            officialImageUrl = null,
            officialVisualNote = "Fotografía del equipo incorporada localmente a partir de las imágenes proporcionadas (referencia de catálogo SOQI Universe / HTE International).",
            officialProductUrl = HTE_BASE_URL,
            secondarySourceUrl = SOQI_UNIVERSE_URL,
            generalDescription = "Equipo de movimiento pasivo ideado por el Dr. Shizuo Inoue que acuna los tobillos mientras la persona descansa boca arriba, generando una oscilación lateral rítmica que se propaga suavemente por piernas, cadera y columna.",
            manufacturer = "HTE International (Hsin Ten Enterprise / Skylite)",
            manufacturerUrl = HTE_BASE_URL,
            technologyUsed = "Oscilación mecánica sinusoidal calibrada de baja amplitud para ejercicio pasivo en decúbito supino.",
            howItWorksSimple = "La persona se recuesta en una superficie firme y coloca sus tobillos en la cuna acolchada. El motor mueve los pies de lado a lado con un ritmo constante (aproximadamente 140 oscilaciones por minuto), imitando el balanceo suave de un pez para relajar la espalda sin impacto articular.",
            verifiedSpecs = listOf(
                TechSpecRow("Oscilación calibrada", "Aproximadamente 140 oscilaciones por minuto"),
                TechSpecRow("Dimensiones aproximadas", "38 x 30 x 23 cm (15\" x 12\" x 9\")"),
                TechSpecRow("Peso aproximado", "6.8 kg (15 lb)"),
                TechSpecRow("Consumo eléctrico", "Motor calibrado ~34–37 W según ficha técnica regional")
            ),
            manufacturerUsage = "El fabricante lo describe como un ejercitador aeróbico pasivo para sesiones cortas (típicamente 5 a 15 minutos) orientadas a favorecer la relajación corporal, liberar tensión en espalda y piernas y complementar rutinas de descanso.",
            relatedResearch = "Existen estudios piloto universitarios (como investigaciones sobre linfedema secundario de extremidades inferiores realizadas en Australia por el equipo del Prof. Neil Piller en Flinders University) que observaron reducciones temporales de volumen de líquido y sensación de pesadez tras sesiones supervisadas.",
            evidenceAndLimitations = "La evidencia disponible procede principalmente de ensayos clínicos pequeños y no sustituye al ejercicio aeróbico activo ni al tratamiento médico especializado del linfedema o cardiopatías. Su uso debe entenderse como movimiento pasivo suave de apoyo.",
            precautionsAndContraindications = listOf(
                "No utilizar durante el embarazo.",
                "Evitar dentro de los primeros 3 meses posteriores a cirugías mayores o fracturas óseas.",
                "Contraindicado en enfermedad cardiaca grave o inestable, hemorragias activas o lesiones recientes.",
                "Usar solo bajo valoración médica en personas con epilepsia o trastornos convulsivos.",
                "Esperar al menos 30 minutos después de ingerir una comida abundante y suspender si aparece mareo o dolor."
            ),
            sources = listOf(
                DeviceSourceLink("Portal oficial HTE International", "HTE International", HTE_BASE_URL),
                DeviceSourceLink("Catálogo informativo SOQI Universe", "SOQI Universe", SOQI_UNIVERSE_URL),
                DeviceSourceLink("Estudios sobre movimiento pasivo y drenaje linfático", "PubMed / Flinders University", "https://pubmed.ncbi.nlm.nih.gov/")
            )
        )
    )
}
