package com.example.data

enum class WellnessSectionRoute(
    val route: String,
    val title: String,
    val subtitle: String,
    val badge: String
) {
    VIDEOS(
        route = "videos",
        title = "Videos educativos populares",
        subtitle = "Rutinas guiadas de movilidad, estiramientos, yoga y recuperación muscular",
        badge = "Tone & Tighten · GAIAM"
    ),
    TECHNOLOGIES(
        route = "technologies",
        title = "Tecnologías y aparatos de bienestar",
        subtitle = "Fichas técnicas, funcionamiento, evidencia y precauciones de equipos HTE",
        badge = "4 equipos documentados"
    ),
    SUPERFOODS(
        route = "superfoods",
        title = "Superalimentos e ingredientes funcionales",
        subtitle = "Hongos funcionales, raíces, especias, semillas y algas con base educativa",
        badge = "10 ingredientes"
    ),
    NUTRITION(
        route = "nutrition",
        title = "Nutrición",
        subtitle = "Proteínas, grasas saludables, carbohidratos, fibra, vitaminas, minerales y antioxidantes",
        badge = "9 guías prácticas"
    ),
    MOVEMENT(
        route = "movement",
        title = "Movimiento y cuidado corporal",
        subtitle = "Yoga, rodillos de masaje, estiramientos, movilidad, flexibilidad y fuerza",
        badge = "6 rutinas seguras"
    ),
    COMMUNITY(
        route = "community",
        title = "Nuestra experiencia en campañas comunitarias",
        subtitle = "Metodología de campo, tamizaje de seguridad y visión de portafolio",
        badge = "Proyecto aplicado"
    ),
    SOURCES(
        route = "sources",
        title = "Fuentes y referencias",
        subtitle = "Organismos de salud pública, literatura científica y fabricantes oficiales",
        badge = "Enlaces verificables"
    )
}

enum class VideoChannel(
    val displayName: String,
    val handle: String,
    val channelUrl: String,
    val specialty: String
) {
    TONE_AND_TIGHTEN(
        displayName = "Tone and Tighten",
        handle = "@toneandtighten",
        channelUrl = "https://www.youtube.com/@toneandtighten",
        specialty = "Fisioterapia educativa, espalda, cuello, rodillas y fortalecimiento"
    ),
    GAIAM(
        displayName = "GAIAM",
        handle = "@gaiam",
        channelUrl = "https://www.youtube.com/@gaiam",
        specialty = "Yoga, flexibilidad, rodillos de masaje y recuperación corporal"
    )
}

enum class VideoCategory(val label: String) {
    ALL("Todos"),
    STRETCHING("Estiramientos"),
    MOBILITY("Movilidad"),
    BACK("Espalda"),
    NECK_SHOULDERS("Cuello y hombros"),
    KNEES("Rodillas"),
    YOGA("Yoga"),
    FLEXIBILITY("Flexibilidad"),
    STRENGTH("Fortalecimiento muscular"),
    FOAM_ROLLER("Rodillos y recuperación")
}

data class EducationalVideo(
    val id: String,
    val title: String,
    val channel: VideoChannel,
    val category: VideoCategory,
    val focusSummary: String,
    val viewsNote: String,
    val localAssetBasePath: String,
    val youtubeVideoId: String? = null,
    val illustrativeImageUrl: String? = null,
    val illustrativeAttribution: String? = null,
    val videoUrl: String,
    val channelUrl: String,
    val estimatedDuration: String
) {
    val thumbnailUrl: String?
        get() = youtubeVideoId?.takeIf { it.isNotBlank() }?.let {
            "https://i.ytimg.com/vi/$it/hqdefault.jpg"
        }
}

data class TechSpecRow(
    val label: String,
    val value: String
)

data class DeviceSourceLink(
    val title: String,
    val organization: String,
    val url: String
)

data class WellnessDevice(
    val id: String,
    val name: String,
    val subtitle: String,
    val localAssetBasePath: String,
    val officialImageUrl: String? = null,
    val officialVisualNote: String,
    val officialProductUrl: String,
    val secondarySourceUrl: String,
    val generalDescription: String,
    val manufacturer: String,
    val manufacturerUrl: String,
    val technologyUsed: String,
    val howItWorksSimple: String,
    val verifiedSpecs: List<TechSpecRow>,
    val manufacturerUsage: String,
    val relatedResearch: String,
    val evidenceAndLimitations: String,
    val precautionsAndContraindications: List<String>,
    val sources: List<DeviceSourceLink>
)

enum class SuperfoodCategory(val label: String) {
    ALL("Todos"),
    MUSHROOMS("Hongos funcionales"),
    ROOTS_SPICES("Raíces y especias"),
    SEEDS_ALGAE("Semillas, algas y hojas")
}

data class SuperfoodItem(
    val id: String,
    val name: String,
    val scientificName: String,
    val category: SuperfoodCategory,
    val localAssetBasePath: String,
    val imageUrl: String,
    val imageAttribution: String,
    val origin: String,
    val bioactiveCompounds: List<String>,
    val practicalUses: String,
    val evidenceLevel: String,
    val scientificSummary: String,
    val precautions: String
)

data class NutritionTopic(
    val id: String,
    val title: String,
    val tag: String,
    val localAssetBasePath: String,
    val imageUrl: String,
    val imageAttribution: String,
    val summary: String,
    val keyPoints: List<String>,
    val practicalMexicanContext: String,
    val commonMythClarified: String
)

data class MovementRoutine(
    val id: String,
    val title: String,
    val bodyArea: String,
    val durationLabel: String,
    val level: String,
    val localAssetBasePath: String,
    val imageUrl: String,
    val imageAttribution: String,
    val objective: String,
    val steps: List<String>,
    val safetyTip: String,
    val relatedVideoCategory: VideoCategory
)

data class CommunityStation(
    val stepNumber: String,
    val title: String,
    val description: String,
    val safetyPractice: String
)

data class CommunityLearning(
    val title: String,
    val detail: String
)

enum class SourceCategory(val label: String) {
    ALL("Todas"),
    PUBLIC_HEALTH("Salud pública"),
    SCIENTIFIC("Evidencia científica"),
    MOVEMENT("Educación física"),
    MANUFACTURERS("Fabricantes")
}

data class ScientificSource(
    val id: String,
    val title: String,
    val organization: String,
    val category: SourceCategory,
    val description: String,
    val url: String
)

data class BookmarkEntry(
    val id: String,
    val type: String,
    val title: String,
    val subtitle: String,
    val targetRoute: String
)
