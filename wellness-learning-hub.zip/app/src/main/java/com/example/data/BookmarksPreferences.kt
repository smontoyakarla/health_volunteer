package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.wellnessDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "wellness_bookmarks_prefs"
)

class BookmarksPreferences(private val context: Context) {
    private val bookmarksKey = stringSetPreferencesKey("saved_item_ids")

    val savedIdsFlow: Flow<Set<String>> = context.wellnessDataStore.data.map { prefs ->
        prefs[bookmarksKey] ?: emptySet()
    }

    suspend fun toggleBookmark(itemId: String) {
        context.wellnessDataStore.edit { prefs ->
            val current = prefs[bookmarksKey] ?: emptySet()
            prefs[bookmarksKey] = if (itemId in current) {
                current - itemId
            } else {
                current + itemId
            }
        }
    }
}
