# Imágenes locales de Wellness Learning Hub

Las imágenes integradas en la aplicación están organizadas por categoría dentro de `app/src/main/assets/images/` (compatibles con `.webp`, `.jpg`, `.jpeg` o `.png`, proporción `16:9`):

## 1. Equipos HTE International (`app/src/main/assets/images/equipos/`) — *Incorporados*
- `equipo_hot_house.png`
- `equipo_e_power.png`
- `equipo_electro_reflex_energizer.png`
- `equipo_sun_ancon_chi_machine.png`

## 2. Inicio (`app/src/main/assets/images/inicio/`)
- `inicio_videos.jpg` *(ilustración editorial incorporada)*
- `inicio_tecnologias.jpg` *(ilustración editorial incorporada)*
- `inicio_comunidad.jpg` *(ilustración editorial incorporada)*
- `inicio_fuentes.jpg` *(ilustración editorial incorporada)*
- Opcionales locales (actualmente usan respaldo específico en línea de Wikimedia Commons): `inicio_hero_bienestar`, `inicio_superalimentos`, `inicio_nutricion`, `inicio_movimiento`

## 3. Ingredientes y Superalimentos (`app/src/main/assets/images/ingredientes/`)
- `ingrediente_reishi`, `ingrediente_melena_de_leon`, `ingrediente_cordyceps`, `ingrediente_jengibre`, `ingrediente_ginseng`, `ingrediente_ashwagandha`, `ingrediente_curcuma`, `ingrediente_chia`, `ingrediente_espirulina`, `ingrediente_matcha`

## 4. Nutrición (`app/src/main/assets/images/nutricion/`)
- `nutricion_proteinas`, `nutricion_vitaminas`, `nutricion_minerales`, `nutricion_antioxidantes`, `nutricion_fibra`, `nutricion_carbohidratos`, `nutricion_alimentos_naturales`, `nutricion_grasas_saludables`, `nutricion_etiquetado`

## 5. Movimiento (`app/src/main/assets/images/movimiento/`)
- `movimiento_yoga`, `movimiento_rodillos_espuma`, `movimiento_estiramientos`, `movimiento_movilidad`, `movimiento_flexibilidad`, `movimiento_fortalecimiento`

## 6. Videos de YouTube (`app/src/main/assets/images/videos/`)
- `video_gaiam_foam_roller.jpg` *(ilustración temática incorporada)*
- Opcionales locales o por `youtubeVideoId` verificado: `video_tt_neck_shoulders`, `video_tt_lower_back`, `video_tt_knees_strength`, `video_tt_full_body_stretch`, `video_tt_core_strength`, `video_gaiam_yoga_beginners`, `video_gaiam_hip_mobility`, `video_gaiam_flexibility`
